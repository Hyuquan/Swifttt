import Foundation
//***********************************************************************************************************************
//22.8
//Associated Types
//关联类型



//Associated Types in Action
//关联类型实践

//定义一个协议时，有的时候声明一个或多个关联类型作为协议定义的一部分将会非常有用。关联类型为协议中的某个类型提供了一个占位名（或者说别名），其代表的实际类型在协议被采纳时才会被指定。你可以通过 associatedtype 关键字来指定关联类型。
protocol Container {
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}
/*
 Container 协议定义了三个任何采纳了该协议的类型（即容器）必须提供的功能：
 
 必须可以通过 append(_:) 方法添加一个新元素到容器里。
 必须可以通过 count 属性获取容器中元素的数量，并返回一个 Int 值。
 必须可以通过索引值类型为 Int 的下标检索到容器中的每一个元素。
 */
//这个协议没有指定容器中元素该如何存储，以及元素必须是何种类型。这个协议只指定了三个任何遵从 Container 协议的类型必须提供的功能。遵从协议的类型在满足这三个条件的情况下也可以提供其他额外的功能。
//任何遵从 Container 协议的类型必须能够指定其存储的元素的类型，必须保证只有正确类型的元素可以加进容器中，必须明确通过其下标返回的元素的类型。
//为了定义这三个条件，Container 协议需要在不知道容器中元素的具体类型的情况下引用这种类型。Container 协议需要指定任何通过 append(_:) 方法添加到容器中的元素和容器中的元素是相同类型，并且通过容器下标返回的元素的类型也是这种类型。
//为了达到这个目的，Container 协议声明了一个关联类型 Item，写作 associatedtype Item。这个协议无法定义 Item 是什么类型的别名，这个信息将留给遵从协议的类型来提供。尽管如此，Item 别名提供了一种方式来引用 Container 中元素的类型，并将之用于 append(_:) 方法和下标，从而保证任何 Container 的行为都能够正如预期地被执行。








//下面是先前的非泛型的 IntStack 类型，这一版本采纳并符合了 Container 协议：
struct IntStack: Container {
    // original IntStack implementation
    // IntStack 的原始实现部分
    var items = [Int]()
    mutating func push(_ item: Int) {
        items.append(item)
    }
    mutating func pop() -> Int {
        return items.removeLast()
    }
    
    
    // conformance to the Container protocol
    // 以下部分代码是Container 协议的实现部分
    typealias Item = Int//此行可以省略
    mutating func append(_ item: Int) {
        self.push(item)
    }
    var count: Int {
        return items.count
    }
    subscript(i: Int) -> Int {
        return items[i]
    }
}
//IntStack类型实现了Container协议的所有三个要求，并且在每种情况下都包含部分IntStack类型的现有功能以满足这些要求。
//此外，IntStack 在实现 Container 的要求时，指定 Item 为 Int 类型，即 typealias Item = Int，从而将 Container 协议中抽象的 Item 类型转换为具体的 Int 类型。
//由于 Swift 的类型推断，你实际上不用在 IntStack 的定义中声明 Item 为 Int。因为 IntStack 符合 Container 协议的所有要求，Swift 只需通过 append(_:) 方法的 item 参数类型和下标返回值的类型，就可以推断出 Item 的具体类型。事实上，如果你在上面的代码中删除了 typealias Item = Int 这一行，一切仍旧可以正常工作，因为 Swift 清楚地知道 Item 应该是哪种类型。



//你也可以让泛型 Stack 结构体遵从 Container 协议：
struct Stack<Element>: Container {
    // original Stack<Element> implementation
    // Stack<Element> 的原始实现部分
    var items = [Element]()
    mutating func push(_ item: Element) {
        items.append(item)
    }
    mutating func pop() -> Element {
        return items.removeLast()
    }
    // conformance to the Container protocol
    // Container 协议的实现部分
    mutating func append(_ item: Element) {
        self.push(item)
    }
    var count: Int {
        return items.count
    }
    subscript(i: Int) -> Element {
        return items[i]
    }
}
//这一次，占位类型参数 Element 被用作 append(_:) 方法的 item 参数和下标的返回类型。Swift 可以据此推断出 Element 的类型即是 Item 的类型。

//以下几句为自己添加的测试语句
var stackOfStringstt = Stack<String>() //String类型
stackOfStringstt.push("uno")
stackOfStringstt.push("djh")
stackOfStringstt.push("idr")
stackOfStringstt.push("pwm")

stackOfStringstt.count
stackOfStringstt[2]//用下标语法去访问


var stackOfInt = Stack<Int>() //Int类型
stackOfInt.push(287)
stackOfInt.push(387)
stackOfInt.push(127)
stackOfInt.push(222)

stackOfInt.count
stackOfInt[3]//用下标语法去访问
//测试语句End
//*******************************************************************************************************************************************************









//Adding Constraints to an Associated Type
//给关联类型添加约束
//你可以给协议里的关联类型添加类型注释，让遵守协议的类型必须遵循这个约束条件。例如，下面的代码定义了一个 Item 必须遵循 Equatable 的 COntainer 类型：
protocol COntainer {
    associatedtype Item: Equatable
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}
//要符合此版本的COntainer，容器的Item类型必须符合Equatable协议。

