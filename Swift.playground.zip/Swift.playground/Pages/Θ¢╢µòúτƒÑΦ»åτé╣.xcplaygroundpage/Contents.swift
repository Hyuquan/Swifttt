
import Foundation

//dynamicMemberLookup

//将此属性应用于类，结构，枚举或协议，以允许在运行时按名称查找成员。该类型必须实现一个subscript(dynamicMemberLookup:)下标。

//在显式成员表达式中，如果没有相应的命名成员声明，则该表达式应理解为对类型的subscript(dynamicMemberLookup:) 下标的调用，并将有关成员的信息作为参数传递。下标可以接受路径或成员名称的参数；如果同时实现两个下标，则使用带有key path参数的下标。

//subscript(dynamicMemberLookup:)的实现可以使用KeyPath，WritableKeyPath或ReferenceWritableKeyPath类型的参数接受键路径。它可以使用符合ExpressibleByStringLiteral协议（在大多数情况下为String）类型的参数来接受成员名称。下标的返回类型可以是任何类型。

//通过成员名称进行动态成员查找可用于围绕在编译时无法进行类型检查的数据创建包装类型，例如，将其他语言的数据桥接到Swift中时。 例如：
@dynamicMemberLookup
struct DynamicStruct {
    let dictionary = ["someDynamicMember": 325,
                      "someOtherMember": 787]
    subscript(dynamicMember member: String) -> Int {
        return dictionary[member] ?? 1054
    }
}

let s = DynamicStruct()

// Use dynamic member lookup.
let dynamic = s.someDynamicMember
print(dynamic)
// Prints "325"

// Call the underlying subscript directly.
let equivalent = s[dynamicMember: "someDynamicMember"]
print(dynamic == equivalent)
// Prints "true"



//通过键路径进行动态成员查找可用于以支持编译时类型检查的方式实现包装器类型。 例如：
struct Point { var x, y: Int }

@dynamicMemberLookup
struct PassthroughWrapper<Value> {
    var value: Value
    subscript<T>(dynamicMember member: KeyPath<Value, T>) -> T
    {
        get { return value[keyPath: member] }
    }
}

let point = Point(x: 381, y: 431)
let wrapper = PassthroughWrapper(value: point)//let wrapper: PassthroughWrapper<Point>
print(wrapper.x)
