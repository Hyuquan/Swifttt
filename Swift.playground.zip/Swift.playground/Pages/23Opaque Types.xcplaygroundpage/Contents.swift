//Opaque Types
//不透明类型
//具有不透明返回类型的函数或方法隐藏其返回值的类型信息。返回值不是提供一个具体的类型作为函数的返回类型，而是根据它支持的协议来描述。隐藏类型信息在模块和调用模块的代码之间的边界处非常有用，因为返回值的底层类型可以保持私有。与返回值为协议类型的值不同，不透明类型保留类型标识，所以编译器可以访问类型信息，而模块的客户端则不能。



//The Problem That Opaque Types Solve
//不透明类型解决的问题
//例如，假设您正在编写绘制ASCII艺术图形的模块。ASCII艺术形状的基本功能是draw（）函数，该函数返回该形状的字符串表示形式，您可以将其用作Shape协议的要求：
protocol Shape {
    func draw() -> String
}

struct Triangle: Shape
{
    var size: Int
    func draw() -> String
    {
        var result = [String]()
        for length in 1...size {
            result.append(String(repeating: "*", count: length))
        }
        return result.joined(separator: "\n")//joined(separator:)是Instance Method。功能是Returns a new string by concatenating the elements of the sequence, adding the given separator between each element.
    }
    
}

let smallTriangle = Triangle(size: 3)
print(smallTriangle.draw())
// *
// **
// ***

print("\n")

//您可以使用泛型来实现诸如垂直翻转形状的操作，如下面的代码所示。 但是，这种方法有一个重要的限制：翻转的结果暴露了用于创建它的确切泛型类型。
struct FlippedShape<T: Shape>: Shape { //struct FlippedShape<T> : Shape where T : Shape
    var shape: T
    func draw() -> String {
        let lines = shape.draw().split(separator: "\n")// split(separator:maxSplits:omittingEmptySubsequences:)是Instance Method。功能是Returns the longest possible subsequences of the collection, in order, around elements equal to the given element.
        return lines.reversed().joined(separator: "\n")
    }
}

let flippedTriangle = FlippedShape(shape: smallTriangle)
print(flippedTriangle.draw())
// ***
// **
// *

print("\n")


//这个实现定义了一个 JoinedShape<T: Shape, U: Shape> 结构体，它能把两个图形垂直地结合在一起，如同下面的代码所示，一个翻转了的三角形与另一个三角形结合后返回的结果类型类似为JoinedShape<Triangle, FlippedShape<Triangle>>
struct JoinedShape<T: Shape, U: Shape>: Shape {//struct JoinedShape<T, U> : Shape where T : Shape, U : Shape
    var top: T
    var bottom: U
    func draw() -> String {
        return top.draw() + "\n" + bottom.draw()//当以下的嵌套调用来到这里时bottom相当于是JoinedShape(top: middle, bottom: bottom)
    }
}

let joinedTriangles = JoinedShape(top: smallTriangle, bottom: flippedTriangle)
//注意 joinedTriangles 的类型
//let joinedTriangles: JoinedShape<Triangle, FlippedShape<Triangle>>
print(joinedTriangles.draw())
// *
// **
// ***
// ***
// **
// *
//公开有关创建形状的详细信息允许不属于ASCII art模块的公共接口的类型泄漏，因为需要声明完整的返回类型。模块内的代码可以以多种方式构建相同的形状，而模块外使用该形状的其他代码不必考虑转换列表的实现细节。像JoinedShape和FlippedShape这样的包装类型对模块的用户来说无关紧要，它们不应该是可见的。模块的公开接口由一系列的操作组成，比如拼接和翻转图形，这些操作返回另一个 Shape 值。


print("\n")




//Returning an Opaque Type
//返回一个不透明类型

//您可以将不透明类型视为与泛型类型相反。泛型类型让代码调用的函数根据实现决定函数形式参数和返回值的类型。举例来说，下面代码的函数返回的类型基于其调用者：
//func max<T>(_ x: T, _ y: T) -> T where T: Comparable { ... }
//调用max（_：_ :)的代码选择x和y的值，这些值的类型确定T的具体类型。调用代码可以使用符合Comparable协议的任何类型。 函数内部的代码以通用方式编写，因此它可以处理调用者提供的任何类型。 max（_：_ :)的实现仅使用所有Comparable类型提供的功能。
//这些角色对于拥有不透明类型返回类型的函数来说恰好相反。不透明类型允许函数在实现时，根据调用它的代码抽象出返回值的类型。例如，以下示例中的函数返回梯形而不暴露该形状的基础类型。


struct Square: Shape {
    var size: Int
    func draw() -> String {
        let line = String(repeating: "*", count: size)
        let result = Array<String>(repeating: line, count: size)//此行 <String> 可以省略。
        return result.joined(separator: "\n")
    }
}

func makeTrapezoid() -> some Shape
{
    let top = Triangle(size: 2)//let top: Triangle
    let middle = Square(size: 2)//let middle: Square
    let bottom = FlippedShape(shape: top)//因为有 let bottom: FlippedShape<Triangle>  所以可以把bottom理解为是FlippedShape类型，同时参数top又是Triangle类型的。
    let trapezoid = JoinedShape(top: top,  bottom: JoinedShape(top: middle, bottom: bottom))//嵌套调用
  //let trapezoid: JoinedShape<Triangle, JoinedShape<Square, FlippedShape<Triangle>>>
    return trapezoid
}

let trapezoid = makeTrapezoid()
print(trapezoid.draw())
// *
// **
// **
// **
// **
// *
//makeTrapezoid() 函数在这个例子中声明了它的返回类型为 some Shape ；结果就是，函数返回一个遵循 Shape 协议的类型，而不需要标明具体类型。这样写 makeTrapezoid() 能让它在公开接口中表达最基本的期望——返回的值是一个图形——不需要特别明确图形是某个公开接口返回的类型。这个实现使用了两个三角形和一个方形，但函数可以重写成用各种方法绘制一个梯形却无需改变它的返回类型。
//这个例子说明了不透明返回类型类似范型的反例。 makeTrapezoid() 内部代码可以返回它需要的任意类型，只要类型遵循 Shape 协议，就像调用范型函数的代码那样。调用函数的代码需要写成范型的方式，就像实现一个范型函数，这样它就可以处理任意 makeTrapezoid() 返回的  Shape 值了。
print("\n")



//你也可以用范型来结合不透明返回类型。下面代码中的函数都返回遵循 Shape 协议的某类型的值。
func flip<T: Shape>(_ shape: T) -> some Shape {
    return FlippedShape(shape: shape)
}

func join<T: Shape, U: Shape>(_ top: T, _ bottom: U) -> some Shape {
    JoinedShape(top: top, bottom: bottom)
}

let opaqueJoinedTriangles = join(smallTriangle, flip(smallTriangle))
print(opaqueJoinedTriangles.draw())
// *
// **
// ***
// ***
// **
// *
//opaqueJoinedTriangles 的值在这个例子中与前文 “不透明类型解决的问题” 小节中范型例子里的 joinedTriangles 一致。总之，与那个例子中值不同的是， flip(_:) 和 join(_:_:) 包装了范型图形操作返回的具体类型为不透明类型，这就避免了那些类型可见。这两个函数都是泛型的，因为它们所依赖的类型是泛型的，并且函数的类型参数会传递FlippedShape和JoinedShape所需的类型信息。
print(" ")


//如果一个带有不透明返回类型的函数从多处返回，所有可能的返回值必须具有相同的类型。对于范型函数，返回类型可以使用函数的范型类型形式参数，但是它必须是单一的类型。比如说，这里有一个包含方块特殊处理的图形翻转函数的错误版本：

//func invalidFlip<T: Shape>(_ shape: T) -> some Shape {
//    if shape is Square {
//        return shape // Error: return types don't match
//    }
//    return FlippedShape(shape: shape) // Error: return types don't match
//}

//如果你用一个 Square 来调用这个函数，它返回一个 Square；否则，它就返回一个 FlippedShape。这违反了返回值必须是一种类型并且让 invalidFlip(_:)发生 错误。一种修复 invalidFlip(_:) 的方法是把对待Square（方块）的特殊情况移动到 FlippedShape2 的实现中去，这就使得这个函数总是返回 FlippedShape 值了：
struct FlippedShape2<T: Shape>: Shape {
    var shape: T
    func draw() -> String
    {
        if shape is Square {
            return shape.draw()
        }
        let lines = shape.draw().split(separator: "\n")
        return lines.reversed().joined(separator: "\n")
    }
}



//总是返回一个类型的约束并不能阻止你在返回不透明类型时使用范型。这里有一个合并它类型形式参数到具体返回类型的函数例子：
func `repeat`<T: Shape>(shape: T, count: Int) -> some Collection {
    //func `repeat`<T>(shape: T, count: Int) -> some Collection where T : Shape
    return Array<T>(repeating: shape, count: count)
}
//在这个情况下，返回值的具体类型依赖 T ：无论什么图形传入， repeat(shape:count:) 都会创建和返回这个图形的数组。就算如此，返回的值也总是同一种类型 [T] ，所以它依旧满足返回不透明类型的函数必须返回同一类型的约束。








//Differences Between Opaque Types and Protocol Types
//不透明类型和协议类型的区别

//返回不透明类型看起来与使用协议类型作为函数返回类型非常相似，但这两种返回类型区别于它们是否保存类型特征。不透明类型指的是一种特定类型，尽管函数的调用者看不到是哪种类型；协议类型可以指符合协议的任何类型。通常来讲，协议类型给它们存储的值的基础类型提供了更大的灵活性，不透明类型则能给你更多关于具体类型的保证。

//比如，这里有一个版本的 flip(_:) 它返回一个协议类型的值而不是不透明类型：

//func protoFlip<T: Shape>(_ shape: T) -> Shape {
//    return FlippedShape(shape: shape)
//}

//这个版本的 protoFlip(_:) 代码和 flip(_:) 一样，并且它也总是返回相同类型的值。和 flip(_:) 不同的是， protoFlip(_:) 返回的值并不要求总是返回相同的类型——它只要遵循 Shape 协议就好了。换句话说，protoFlip（_ :)与调用者之间的API合同要比flip（_ :)宽松得多。 它保留返回多种类型的值的灵活性：
func protoFlip<T: Shape>(_ shape: T) -> Shape {
    if shape is Square {
        return shape
    }

    return FlippedShape(shape: shape)
}
//修改过的代码返回一个 Square 的实例或者是 FlippedShape 的实例，基于传入的图形决定。这个函数返回的两个翻转过的图形可能拥有完全不同的类型。此函数的其他有效版本会在翻转多个相同图形的实例时返回不同类型的值。 protoFlip(_:) 具有更少的特定返回类型信息，这就意味着很多依赖类型信息的操作无法完成。比如， == 运算符就无法比较这个函数返回的结果。
let protoFlippedTriangle = protoFlip(smallTriangle)
let sameThing = protoFlip(smallTriangle)
//protoFlippedTriangle == sameThing  // Error
//最后一行的错误有很多引发原因。最直接的问题是 Shape 并没有 == 运算符作为其协议要求的一部分。如果你尝试添加，那么接下来会遇到的问题是 == 运算符需要知道左边实际参数和右边实际参数的类型。这一系列运算符通常取实际参数的类型为 Self 类型，匹配任何遵循协议的具体类型，但添加 Self 需求给协议并不能让类型保证你在使用协议作为类型时能匹配成功。
//使用协议类型作为函数的返回类型能给你带来不少灵活性以返回任意遵循协议的类型。总之，这样灵活性的代价就是返回值无法使用某些运算。以上例子展示了 == 运算符为何不可用————它需要基于特定的类型信息但协议类型无法提供。
//这么做的另一个问题是图形转换不能嵌套。翻转三角形的结果是一个 Shape 类型的值， protoFlip(_:) 函数接受一个遵循 Shape 协议的某类型作为实际参数。然而，协议类型的值并不遵循那个协议； protoFlip(_:) 返回的值并不遵循 Shape 。这就意味着类似 protoFlip(protoFlip(smallTriange)) 这样应用多个转换的代码是不合法的，因为翻转了的图形不是 protoFlip(_:) 合法的实际参数。

//相反，不透明类型保持了具体类型的特征。Swift 可以推断相关类型，这就使得你能在某些不能把协议类型作为返回类型的地方使用不透明类型。例如，这里有一个版本的 Container 协议，它来自范型这章。
protocol Container {
    associatedtype Item
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}

extension Array: Container { }
//你不能使用 Container 作为函数的返回类型，因为这个协议有一个关联类型。你也不能使用它作为范型返回类型的约束因为它在函数体外没有足够的信息来推断它到底需要成为什么范型类型。
/*

// Error: Protocol with associated types can't be used as a return type.
func makeProtocolContainer<T>(item: T) -> Container {
    return [item]
}

// Error: Not enough information to infer C.
func makeProtocolContainer<T, C: Container>(item: T) -> C {
    return [item]
}

 */



//使用不透明类型 some Container 作为返回类型则能够表达期望的 API 约束——函数返回一个容器，但不指定特定的容器类型：
func makeOpaqueContainer<T>(item: T) -> some Container {
    return [item]
}

let opaqueContainer = makeOpaqueContainer(item: 12)//let opaqueContainer: some Container
let twelve = opaqueContainer[0]//let twelve: (some Container).Item
print(type(of: twelve))
// Prints "Int"
//twelve 类型被推断为 Int ，这展示了类型类型推断能够在不透明类型上正常运行的事实。在 makeOpaqueContainer(item:) 的实现中，不透明容器的具体类型是 [T] 。在这个例子中， T 是 Int ，所以返回值是一个整数的数组并且 Item 的关联类型被推断为 Int 。 Container 的下标返回 Item ，也就是说 twelve 的类型也被推断为 Int 。


print(twelve)//自举例
