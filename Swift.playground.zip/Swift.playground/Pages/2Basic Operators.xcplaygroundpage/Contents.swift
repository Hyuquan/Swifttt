//: Playground - noun: a place where people can play

import UIKit




//你同样可以比较拥有同样数量值的元组，只要元组中的每个值都是可比较的。比如说， Int 和 String 都可以用来比较大小，也就是说 (Int,String) 类型的元组就可以比较。
//元组以从左到右的顺序比较大小，一次一个值，直到找到两个不相等的值为止。如果所有的值都是相等的，那么就认为元组本身是相等的。比如说：
(1, "zebra") < (2, "apple")   // true because 1 is less than 2
(3, "apple") < (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
(4, "dog") == (4, "dog")      // true because 4 is equal to 4, and "dog" is equal to "dog"
//注意：Swift 标准库包含的元组比较运算符仅支持小于七个元素的元组。要比较拥有七个或者更多元素的元组，你必须自己实现比较运算符。
("blue", -1) < ("purple", 1)        // OK, evaluates to true
//一般来说， Bool 不能比较，这意味着包含布尔值的元组不能用来比较大小。
//("blue", false) < ("purple", true)
// Error because < can't compare Boolean values



//Here’s an example, which calculates the height for a table row. The row height should be 50 points taller than the content height if the row has a header, and 20 points taller if the row doesn’t have a header:
let contentHeight = 40
let hasHeader = true
let rowHeight = contentHeight + (hasHeader ? 50 : 20)
// rowHeight is equal to 90



//合并空值运算符

//合并空值运算符 （ a ?? b ）如果可选项 a  有值则展开，如果没有值，是 nil  ，则返回默认值 b 。表达式 a 必须是一个可选类型。表达式 b  必须与 a  的储存类型相同。

//下边的例子使用了合并空值运算符来在默认颜色名和可选的用户定义颜色名之间做选择：
let defaultColorName = "red"
var userDefinedColorName: String?   // defaults to nil

var colorNameToUse = userDefinedColorName ?? defaultColorName
//userDefinedColorName  变量被定义为可选的 String  ，默认为 nil  。由于 userDefinedColorName  是一个可选类型，你可以使用合并空值运算符来控制它的值。在上边的例子当中，这个运算符被用来决定 String  类型的变量 colorNameToUse  的初始值。因为 userDefinedColorName  是 nil ，表达式 userDefinedColorName ?? defaultColorName  返回了 defaultColorName  的值， "red" 。


//如果你给 userDefinedColorName  指定一个非空的值然后让合并空值运算符再检查一次，那么 userDefinedColorName  中封装的值将会替换掉默认值：
userDefinedColorName = "green"
colorNameToUse = userDefinedColorName ?? defaultColorName
// userDefinedColorName is not nil, so colorNameToUse is set to "green"



//Range Operators

//Closed Range Operator
//The closed range operator (a...b) defines a range that runs from a to b, and includes the values a and b. The value of a must not be greater than b.
//The closed range operator is useful when iterating over a range in which you want all of the values to be used, such as with a for-in loop:
    
    for index in 1...5 {
        print("\(index) times 5 is \(index * 5)")
        
}



//半开区间运算符
//半开区间运算符（ a..<b ）定义了从 a  到 b  但不包括 b  的区间，即 半开 ，因为它只包含起始值但并不包含结束值。如同闭区间运算符， a  的值也不能大于 b  ，如果 a  与 b  的值相等，那返回的区间将会是空的。
//Half-open ranges are particularly useful when you work with zero-based lists such as arrays, where it’s useful to count up to (but not including) the length of the list:
let names = ["Anna", "Alex", "Brian", "Jack"]
let count = names.count
for i in 0..<count {
    print("Person \(i + 1) is called \(names[i])")
}
//注意数组包含四个元素，但是 0..<count  只遍历到 3（元素序号的最大值），因为这是一个半开区间。关于数组的更多内容，参见数组。


//单侧区间

//闭区间有另外一种形式来让区间朝一个方向尽可能的远——比如说，一个包含数组所有元素的区间，从索引 2 到数组的结束。在这种情况下，你可以省略区间运算符一侧的值。因为运算符只有一侧有值，所以这种区间叫做单侧区间。比如说：
for name in names[2...] {
    print(name)
}
// Brian
// Jack

for name in names[...2] {
    print(name)
}
// Anna
// Alex
// Brian

//半开区间运算符同样可以有单侧形式，只需要写它最终的值。和你两侧都包含值一样，最终的值不是区间的一部分。举例来说：
for name in names[..<2] {
    print(name)
}
// Anna
// Alex



//单侧区间可以在其他上下文中使用，不仅仅是下标。你不能遍历省略了第一个值的单侧区间，因为遍历根本不知道该从哪里开始。你可以遍历省略了最终值的单侧区间；总之，由于区间无限连续，你要确保给循环添加一个显式的条件。你同样可以检测单侧区间是否包含特定的值，就如下面的代码所述。
let range = ...5
range.contains(7)   // false
range.contains(4)   // true
range.contains(-1)  // true



//Logical Operators

//Logical NOT Operator
let allowedEntry = false
if !allowedEntry {
    print("ACCESS DENIED")
}


//Logical AND Operator
let enteredDoorCode = true
let passedRetinaScan = false
if enteredDoorCode && passedRetinaScan {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}
// Prints "ACCESS DENIED"


//逻辑或运算符
//Logical OR Operator
let hasDoorKey = false
let knowsOverridePassword = true
if hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}
// Prints "Welcome!"


//混合逻辑运算
//Combining Logical Operators
if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}
// Prints "Welcome!"
//Explicit Parentheses（添加括号使程序更易读）
if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}
// Prints "Welcome!"





