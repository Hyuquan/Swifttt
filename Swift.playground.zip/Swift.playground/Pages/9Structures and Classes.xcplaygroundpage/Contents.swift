//: Playground - noun: a place where people can play

import UIKit


//Structures and Classes
//结构体和类

//类和结构体是人们构建代码所用的一种通用且灵活的构造体。
//通常一个类的实例被称为对象。

//Definition Syntax
//定义语法
//类和结构体有着类似的定义方式。我们通过关键字 class 和 struct 来分别表示类和结构体，并在一对大括号中定义它们的具体内容：
struct SomeStructure {
    // 在这里定义结构体
}

class SomeClass {
    // 在这里定义类
}



//Structure and Class Instances
//类和结构体实例：Resolution 结构体和 VideoMode 类的定义仅描述了什么是 Resolution 和 VideoMode。它们并没有描述一个特定的分辨率（resolution）或者视频模式（video mode）。为了描述一个特定的分辨率或者视频模式，我们需要生成一个它们的实例。
//以下是定义结构体和定义类的示例：
struct Resolution {
    var width = 0
    var height = 0
}

class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

//生成结构体和类实例的语法非常相似：
let someResolution = Resolution()
let someVideoMode = VideoMode()
//结构体和类都使用构造器语法来生成新的实例。构造器语法的最简单形式是在结构体或者类的类型名称后跟随一对空括号，如 Resolution() 或 VideoMode()。通过这种方式所创建的类或者结构体实例，其属性均会被初始化为默认值。


//Accessing Properties
//属性访问
//通过使用点语法，你可以访问实例的属性。其语法规则是，实例名后面紧跟属性名，两者通过点号（.）连接：
print("The width of someResolution is \(someResolution.width)")
// Prints "The width of someResolution is 0"

//你也可以访问子属性，如 VideoMode 中 Resolution 属性的 width 属性：
print("The width of someVideoMode is \(someVideoMode.resolution.width)")
// 打印 "The width of someVideoMode is 0"

//你也可以使用点语法为变量属性赋值：
someVideoMode.resolution.width = 1280
print("The width of someVideoMode is now \(someVideoMode.resolution.width)")
// 打印 "The width of someVideoMode is now 1280"




//Memberwise Initializers for Structure Types
//结构体类型的成员逐一构造器
let vga = Resolution(width: 640, height: 480)
print(vga.width)
//所有结构体都有一个自动生成的成员逐一构造器，用于初始化新结构体实例中成员的属性。新实例中各个属性的初始值可以通过属性的名称传递到成员逐一构造器之中：
//与结构体不同，类实例没有默认的成员逐一构造器。构造过程章节会对构造器进行更详细的讨论。




//Structures and Enumerations Are Value Types
//结构体和枚举是值类型
//在 Swift 中，所有的结构体和枚举类型都是值类型。这意味着它们的实例，以及实例中所包含的任何值类型属性，在代码中传递的时候都会被复制。
//请看下面这个示例，其使用了前一个示例中的 Resolution 结构体：
let hd = Resolution(width: 1920, height: 1080)//结构体类型的成员逐一构造器
var cinema = hd
//在以上示例中，声明了一个名为 hd 的常量，其值为一个初始化为全高清视频分辨率（1920 像素宽，1080 像素高）的 Resolution 实例。然后示例中又声明了一个名为 cinema 的变量，并将 hd 赋值给它。因为 Resolution 是一个结构体，所以 cinema 的值其实是 hd 的一个拷贝副本，而不是 hd 本身。尽管 hd 和 cinema 有着相同的宽（width）和高（height），但是在幕后它们是两个完全不同的实例。
//下面，为了符合数码影院放映的需求（2048 像素宽，1080 像素高），cinema 的 width 属性需要作如下修改：
cinema.width = 2048
//Checking the width property of cinema shows that it has indeed changed to be 2048:
print("cinema is now \(cinema.width) pixels wide")
// Prints "cinema is now 2048 pixels wide"
//However, the width property of the original hd instance still has the old value of 1920:
print("hd is still \(hd.width) pixels wide")
// Prints "hd is still 1920 pixels wide"
//在将 hd 赋予给 cinema 的时候，实际上是将 hd 中所存储的值进行拷贝，然后将拷贝的数据存储到新的 cinema 实例中。结果就是两个完全独立的实例碰巧包含有相同的数值。由于两者相互独立，因此将 cinema 的 width 修改为 2048 并不会影响 hd 中的 width 的值。





//The same behavior applies to enumerations:
//枚举也遵循相同的特性和准则：
enum CompassPoint {
    case north, south, east, west
    mutating func turnNorth() {
        /*  参考11Methods里的
            Modifying Value Types from Within Instance Methods
            在实例方法中修改值类型
        */
        //结构体和枚举是值类型。默认情况下，值类型的属性不能在它的实例方法中被修改。但是，如果你确实需要在某个特定的方法中修改结构体或者枚举的属性，你可以为这个方法选择 ——可变（mutating）行为，然后就可以从其方法内部改变它的属性；并且这个方法做的任何改变都会在方法执行结束时写回到原始结构中。方法还可以给它隐含的 self 属性赋予一个全新的实例，这个新实例在方法结束时会替换现存实例。
        //要使用可变方法，将关键字 mutating 放到方法的 func 关键字之前就可以了：
        self = .north
    }
}
var currentDirection = CompassPoint.west
let rememberedDirection = currentDirection
currentDirection.turnNorth()

print("The current direction is \(currentDirection)")
// Prints "The current direction is north"
print("The remembered direction is \(rememberedDirection)")
// Prints "The remembered direction is west"
//When rememberedDirection is assigned the value of currentDirection, it’s actually set to a copy of that value. Changing the value of currentDirection thereafter doesn’t affect the copy of the original value that was stored in rememberedDirection.
//上例中 rememberedDirection 被赋予了 currentDirection 的值，实际上它被赋予的是值的一个拷贝。赋值过程结束后再修改 currentDirection 的值并不影响 rememberedDirection 所储存的原始值的拷贝。




//Classes Are Reference Types
//类是引用类型
//与值类型不同，引用类型在被赋予到一个变量、常量或者被传递到一个函数时，其值不会被拷贝。因此，引用的是已存在的实例本身而不是其拷贝。请看下面这个示例，其使用了之前定义的 VideoMode 类：
let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0
//以上示例中，声明了一个名为 tenEighty 的常量，其引用了一个 VideoMode 类的新实例。在之前的示例中，这个视频模式（video mode）被赋予了 HD 分辨率（1920*1080）的一个拷贝（即 hd 实例）。同时设置为 interlaced，命名为 “1080i”。最后，其帧率是 25.0 帧每秒。
//然后，tenEighty 被赋予名为 alsoTenEighty 的新常量，同时对 alsoTenEighty 的帧率进行修改：
let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0
//因为类是引用类型，所以 tenEight 和 alsoTenEight 实际上引用的是相同的 VideoMode 实例。换句话说，它们是同一个实例的两种叫法。
//下面，通过查看 tenEighty 的 frameRate 属性，我们会发现它正确的显示了所引用的 VideoMode 实例的新帧率，其值为 30.0：
print("The frameRate property of tenEighty is now \(tenEighty.frameRate)")
// Prints "The frameRate property of tenEighty is now 30.0"
//需要注意的是 tenEighty 和 alsoTenEighty 被声明为常量而不是变量。然而你依然可以改变 tenEighty.frameRate 和 alsoTenEighty.frameRate，因为 tenEighty 和 alsoTenEighty 这两个常量的值并未改变。它们并不“存储”这个 VideoMode 实例，而仅仅是对 VideoMode 实例的引用。所以，改变的是被引用的 VideoMode 的 frameRate 属性，而不是引用 VideoMode 的常量的值。


//Identity Operators
//恒等运算符
/*因为类是引用类型，有可能有多个常量和变量在幕后同时引用同一个类实例。（对于结构体和枚举来说，这并不成立。因为它们作为值类型，在被赋予到常量、变量或者传递到函数时，其值总是会被拷贝。）如果能够判定两个常量或者变量是否引用同一个类实例将会很有帮助。为了达到这个目的，Swift 内建了两个恒等运算符：
等价于（===）
不等价于（!==）
运用这两个运算符检测两个常量或者变量是否引用同一个实例：
*/
if tenEighty === alsoTenEighty {
    print("tenEighty and alsoTenEighty refer to the same VideoMode instance.")
}
// Prints "tenEighty and alsoTenEighty refer to the same VideoMode instance."
/*
 请注意，“等价于”（用三个等号表示，===）与“等于”（用两个等号表示，==）的不同：
“等价于”表示两个类类型（class type）的常量或者变量引用同一个类实例。
“等于”表示两个实例的值“相等”或“相同”，判定时要遵照设计者定义的评判标准，因此相对于“相等”来说，这是一种更加合适的叫法。
当你在定义你的自定义类和结构体的时候，你有义务来决定判定两个实例“相等”的标准。在章节等价操作符中将会详细介绍实现自定义“等于”和“不等于”运算符的流程。
*/


