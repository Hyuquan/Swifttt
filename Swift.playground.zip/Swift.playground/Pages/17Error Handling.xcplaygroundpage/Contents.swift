import UIKit

//Error Handling
//错误处理

/*
    Error handling is the process of responding to and recovering from error conditions in your program. Swift provides
  first-class support for throwing, catching, propagating, and manipulating recoverable errors at runtime.
    Some operations aren’t guaranteed to always complete execution or produce a useful output. Optionals are used to
  represent the absence of a value, but when an operation fails, it’s often useful to understand what caused the failure,
  so that your code can respond accordingly.
    As an example, consider the task of reading and processing data from a file on disk. There are a number of ways this
  task can fail, including the file not existing at the specified path, the file not having read permissions, or the file
  not being encoded in a compatible format. Distinguishing among these different situations allows a program to resolve
  some errors and to communicate to the user any errors it can’t resolve.
 
  错误处理（Error handling）是响应错误以及从错误中恢复的过程。Swift 提供了在运行时对可恢复错误的抛出、捕获、传递和操作的一类支持。

  某些操作无法保证总是执行完所有代码或总是生成有用的结果。可选类型可用来表示值缺失，但是当某个操作失败时，最好能得知失败的原因，从而可以作出相应的应对。
 
  举个例子，假如有个从磁盘上的某个文件读取数据并进行处理的任务，该任务会有多种可能失败的情况，包括指定路径下文件并不存在，文件不具有可读权限，或者文件
  编码格式不兼容。区分这些不同的失败情况可以让程序解决并处理某些错误，然后把它解决不了的错误报告给用户。
*/



//************************************************************************************************************************
//17.1
//Representing and Throwing Errors
//表示并抛出错误
//In Swift, errors are represented by values of types that conform to the Error protocol. This empty protocol indicates that a type can be used for error handling.
//在 Swift 中，错误用符合 Error 协议的类型的值来表示。这个空协议表明该类型可以用于错误处理。

//Swift enumerations are particularly well suited to modeling a group of related error conditions, with associated values allowing for additional information about the nature of an error to be communicated. For example, here’s how you might represent the error conditions of operating a vending machine inside a game:
//Swift 的枚举类型尤为适合构建一组相关的错误状态，枚举的关联值还可以提供错误状态的额外信息。例如，你可以这样表示在一个游戏中操作自动贩卖机时可能会出现的错误状态：

enum VendingMachineError: Error {
    case invalidSelection
    case insufficientFunds(coinsNeeded: Int)
    case outOfStock
}


//Throwing an error lets you indicate that something unexpected happened and the normal flow of execution can’t continue. You use a throw statement to throw an error. For example, the following code throws an error to indicate that five additional coins are needed by the vending machine:
//抛出一个错误可以让你表明有意外情况发生，导致正常的执行流程无法继续执行。抛出错误使用 throw 关键字。例如，下面的代码抛出一个错误，提示贩卖机还需要 5 个硬币：
//  throw VendingMachineError.insufficientFunds(coinsNeeded: 5)
//************************************************************************************************************************






//************************************************************************************************************************
//17.2
//Handling Errors
//处理错误
/*
   When an error is thrown, some surrounding piece of code must be responsible for handling the error—for example, by
 correcting the problem, trying an alternative approach, or informing the user of the failure.
   There are four ways to handle errors in Swift. You can propagate the error from a function to the code that calls that
 function, handle the error using a do-catch statement, handle the error as an optional value, or assert that the error
 will not occur. Each approach is described in a section below.
   When a function throws an error, it changes the flow of your program, so it’s important that you can quickly identify
 places in your code that can throw errors. To identify these places in your code, write the try keyword—or the try? or
 try! variation—before a piece of code that calls a function, method, or initializer that can throw an error. These
 keywords are described in the sections below.
   某个错误被抛出时，附近的某部分代码必须负责处理这个错误，例如纠正这个问题、尝试另外一种方式、或是向用户报告错误。
   Swift 中有 4 种处理错误的方式。你可以把函数抛出的错误传递给调用此函数的代码、用 do-catch 语句处理错误、将错误作为可选类型处理、或者断言此错误
 根本不会发生。每种方式在下面的小节中都有描述。
   当一个函数抛出一个错误时，你的程序流程会发生改变，所以重要的是你能迅速识别代码中会抛出错误的地方。为了标识出这些地方，在调用一个能抛出错误的函数、
 方法或者构造器之前，加上 try 关键字，或者 try? 或 try! 这种变体。这些关键字在下面的小节中有具体讲解。
*/

//NOTE:Error handling in Swift resembles exception handling in other languages, with the use of the try, catch and throw keywords. Unlike exception handling in many languages—including Objective-C—error handling in Swift does not involve unwinding the call stack, a process that can be computationally expensive. As such, the performance characteristics of a throw statement are comparable to those of a return statement.
//注意：Swift 中的错误处理和其他语言中用 try，catch 和 throw 进行异常处理很像。和其他语言中（包括 Objective-C ）的异常处理不同的是，Swift 中的错误处理并不涉及解除调用栈，这是一个计算代价高昂的过程。就此而言，throw 语句的性能特性是可以和 return 语句相媲美的。



//Propagating Errors Using Throwing Functions
//用 throwing 函数传递错误
/*
 
 To indicate that a function, method, or initializer can throw an error, you write the throws keyword in the function’s declaration after its parameters. A function marked with throws is called a throwing function. If the function specifies a return type, you write the throws keyword before the return arrow (->).
 为了表示一个函数、方法或构造器可以抛出错误，在函数声明的参数列表之后加上 throws 关键字。一个标有 throws 关键字的函数被称作throwing 函数。如果这个函数指明了返回值类型，throws 关键词需要写在箭头（->）的前面。如下所示：
 
  func canThrowErrors() throws -> String    (A function marked with throws is called a throwing function.)

  func cannotThrowErrors() -> String
 
 A throwing function propagates errors that are thrown inside of it to the scope from which it’s called.
 一个 throwing 函数可以在其内部抛出错误，并将错误传递到函数被调用时的作用域。
 
 NOTE:Only throwing functions can propagate errors. Any errors thrown inside a nonthrowing function must be handled inside
      the function.
 注意：只有 throwing 函数可以传递错误。任何在某个非 throwing 函数内部抛出的错误只能在函数内部处理。
 
*/



//In the example below, the VendingMachine class has a vend(itemNamed:) method that throws an appropriate VendingMachineError if the requested item is not available, is out of stock, or has a cost that exceeds the current deposited amount:
//在下边的例子中， VendingMachine类拥有一个如果请求的物品不存在、卖光了或者比押金贵了就会抛出对应的 VendingMachineError错误的 vend(itemNamed:)方法：
struct Item {
    var price: Int
    var count: Int
}

class VendingMachine {
    var inventory = [
        "Candy Bar": Item(price: 12, count: 7),
        "Chips": Item(price: 10, count: 4),
        "Pretzels": Item(price: 7, count: 11)
    ]
    
    var coinsDeposited = 0
    
    func vend(itemNamed name: String) throws {
        guard let item = inventory[name] else {
            throw VendingMachineError.invalidSelection
        }
        
        guard item.count > 0 else {
            throw VendingMachineError.outOfStock
        }
        
        guard item.price <= coinsDeposited else {
            throw VendingMachineError.insufficientFunds(coinsNeeded: item.price - coinsDeposited)
        }
        
        coinsDeposited -= item.price
        
        var newItem = item
        newItem.count -= 1
        inventory[name] = newItem
        
        print("Dispensing \(name)")
    }
    
}
//The implementation of the vend(itemNamed:) method uses guard statements to exit the method early and throw appropriate errors if any of the requirements for purchasing a snack aren’t met. Because a throw statement immediately transfers program control, an item will be vended only if all of these requirements are met.
//vend(itemNamed:)方法的实现使用了 guard语句来提前退出并抛出错误，如果购买零食的条件不符合的话。因为 throw语句立即传送程序控制，所以只有所有条件都达到，物品才会售出。


//Because the vend(itemNamed:) method propagates any errors it throws, any code that calls this method must either handle the errors—using a do-catch statement, try?, or try!—or continue to propagate them. For example, the buyFavoriteSnack(person:vendingMachine:) in the example below is also a throwing function, and any errors that the vend(itemNamed:) method throws will propagate up to the point where the buyFavoriteSnack(person:vendingMachine:) function is called.
let favoriteSnacks = [
    "Alice": "Chips",
    "Bob": "Licorice",
    "Eve": "Pretzels",
]


func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws {
    let snackName = favoriteSnacks[person] ?? "Candy Bar"
    try vendingMachine.vend(itemNamed: snackName)//Because the vend(itemNamed:) method can throw an error, it’s called with the try keyword in front of it.
}
//In this example, the buyFavoriteSnack(person: vendingMachine:) function looks up a given person’s favorite snack and tries to buy it for them by calling the vend(itemNamed:) method. Because the vend(itemNamed:) method can throw an error, it’s called with the try keyword in front of it.




//Throwing initializers can propagate errors in the same way as throwing functions. For example, the initializer for the PurchasedSnack structure in the listing below calls a throwing function as part of the initialization process, and it handles any errors that it encounters by propagating them to its caller.
struct PurchasedSnack {
    let name: String
    init(name: String, vendingMachine: VendingMachine) throws {//Throwing initializers can propagate errors in the same way as throwing functions.
        try vendingMachine.vend(itemNamed: name)
        self.name = name
    }
}



//For example, the following code matches against all three cases of the VendingMachineError enumeration.
var vendingMachine = VendingMachine()
vendingMachine.coinsDeposited = 8   //修改这里的参数可以观察程序在不同参数下的走向流程

//Handling Errors Using Do-Catch
//You use a do-catch statement to handle errors by running a block of code. If an error is thrown by the code in the do clause, it is matched against the catch clauses to determine which one of them can handle the error.
do {
    try buyFavoriteSnack(person: "Alice", vendingMachine: vendingMachine)//the buyFavoriteSnack(person:vendingMachine:) function is called in a try expression, because it can throw an error.
    print("Success! Yum.")// If no error is thrown, the remaining statements in the do statement are executed.
}
catch VendingMachineError.invalidSelection
{
    print("Invalid Selection.")
}
catch VendingMachineError.outOfStock
{
    print("Out of Stock.")
}
catch VendingMachineError.insufficientFunds(let coinsNeeded)//涉及枚举里的关联值绑定的知识点。
{
    print("Insufficient funds. Please insert an additional \(coinsNeeded) coins.")
}
catch
{
    print("Unexpected error: \(error).")//You write a pattern after catch to indicate what errors that clause can handle. If a catch clause doesn’t have a pattern, the clause matches any error and binds the error to a local constant named error. For more information about pattern matching, see Patterns.
}
// Prints "Insufficient funds. Please insert an additional 2 coins."
//In the above example, the buyFavoriteSnack(person:vendingMachine:) function is called in a try expression, because it can throw an error. If an error is thrown, execution immediately transfers to the catch clauses, which decide whether to allow propagation to continue. If no pattern is matched, the error gets caught by the final catch clause and is bound to a local error constant. If no error is thrown, the remaining statements in the do statement are executed.


//The catch clauses don’t have to handle every possible error that the code in the do clause can throw. If none of the catch clauses handle the error, the error propagates to the surrounding scope. However, the propagated error must be handled by some surrounding scope. In a nonthrowing function, an enclosing do-catch clause must handle the error. In a throwing function, either an enclosing do-catch clause or the caller must handle the error. If the error propagates to the top-level scope without being handled, you’ll get a runtime error.
//For example, the above example can be written so any error that isn’t a VendingMachineError is instead caught by the calling function:
func nourish(with item: String) throws {
    do {
        try vendingMachine.vend(itemNamed: item)
    } catch is VendingMachineError {
        print("Invalid selection, out of stock, or not enough money.")
    }
}


do {
    try nourish(with: "Beet-Flavored Chips")
} catch {
    print("Unexpected non-vending-machine-related error: \(error)")
}
// Prints "Invalid selection, out of stock, or not enough money."
//In the nourish(with:) function, if vend(itemNamed:) throws an error that’s one of the cases of the VendingMachineError enumeration, nourish(with:) handles the error by printing a message. Otherwise, nourish(with:) propagates the error to its call site. The error is then caught by the general catch clause.



//Converting Errors to Optional Values
//转换错误为可选项
 
//You use try? to handle an error by converting it to an optional value. If an error is thrown while evaluating the try? expression, the value of the expression is nil. For example, in the following code x and y have the same value and behavior:
//使用 try?通过将错误转换为可选项来处理一个错误。如果一个错误在 try?表达式中抛出，则表达式的值为 nil。比如说下面的代码x和y拥有同样的值和行为：




//func someThrowingFunction() throws -> Int {
//      // ...
//
//}
//
//let x = try? someThrowingFunction()
//
//let y: Int?
//do {
//    y = try someThrowingFunction()
//} catch {
//    y = nil
//}
 




//If someThrowingFunction() throws an error, the value of x and y is nil. Otherwise, the value of x and y is the value that the function returned. Note that x and y are an optional of whatever type someThrowingFunction() returns. Here the function returns an integer, so x and y are optional integers.
//如果 someThrowingFunction()抛出一个错误， x和 y的值就是 nil。另一方面，x和y的值是函数返回的值。注意 x和 y是可选的无论 someThrowingFunction()返回什么类型，这里函数返回了一个整数，所以x和y是可选整数。



//Using try? lets you write concise error handling code when you want to handle all errors in the same way. For example, the following code uses several approaches to fetch data, or returns nil if all of the approaches fail.
//当你想要在同一句里处理所有错误时，使用 try?能让你的错误处理代码更加简洁。比如，下边的代码使用了一些方法来获取数据，或者在所有方式都失败后返回 nil。

//func fetchData() -> Data? {
//    if let data = try? fetchDataFromDisk() { return data }
//    if let data = try? fetchDataFromServer() { return data }
//    return nil
//}


//Disabling Error Propagation
//取消错误传递

//事实上有时你已经知道一个抛出错误或者方法不会在运行时抛出错误。在这种情况下，你可以在表达式前写try!来取消错误传递并且把调用放进不会有错误抛出的运行时断言当中。如果错误真的抛出了，你会得到一个运行时错误。
//比如说，下面的代码使用了loadImage(_:) 函数，它在给定路径下加载图像资源，如果图像不能被加载则抛出一个错误。在这种情况下，由于图像跟着应用走，运行时不会有错误抛出，所以取消错误传递是合适的。

//let photo = try! loadImage("./Resources/John Appleseed.jpg")


//************************************************************************************************************************







//************************************************************************************************************************
//17.3
//Specifying Cleanup Actions
//指定清理操作

//    You use a defer statement to execute a set of statements just before code execution leaves the current block of code. This statement lets you do any necessary cleanup that should be performed regardless of how execution leaves the current block of code—whether it leaves because an error was thrown or because of a statement such as return or break. For example, you can use a defer statement to ensure that file descriptors are closed and manually allocated memory is freed.
//    A defer statement defers execution until the current scope is exited. This statement consists of the defer keyword and the statements to be executed later. The deferred statements may not contain any code that would transfer control out of the statements, such as a break or a return statement, or by throwing an error. Deferred actions are executed in the reverse of the order that they’re written in your source code. That is, the code in the first defer statement executes last, the code in the second defer statement executes second to last, and so on. The last defer statement in source code order executes first.

//你可以使用defer语句在即将离开当前代码块时执行一系列语句。该语句让你能执行一些必要的清理工作，不管是以何种方式离开当前代码块的——无论是由于抛出错误而离开，或是由于诸如 return、break 的语句。例如，你可以用 defer 语句来确保文件描述符得以关闭，以及手动分配的内存得以释放。
//   defer 语句将代码的执行延迟到当前的作用域退出之前。该语句由 defer 关键字和要被延迟执行的语句组成。延迟执行的语句不能包含任何控制转移语句，例如 break、return 语句，或是抛出一个错误。延迟执行的操作会按照它们声明的顺序从后往前执行——也就是说，第一条 defer 语句中的代码最后才执行，第二条 defer 语句中的代码倒数第二个执行，以此类推。最后一条语句会第一个执行。
/*

func processFile(filename: String) throws {
    if exists(filename) {
        let file = open(filename)
        defer {
            close(file)
        }
        while let line = try file.readline() {
            // Work with the file.
        }
        // close(file) is called here, at the end of the scope.
    }
}
 
*/
 
//The above example uses a defer statement to ensure that the open(_:) function has a corresponding call to close(_:).
//上面的代码使用一条 defer 语句来确保 open(_:) 函数有一个相应的对 close(_:) 函数的调用。

//************************************************************************************************************************

