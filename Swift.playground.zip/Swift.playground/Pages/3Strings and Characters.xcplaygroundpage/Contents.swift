//: Playground - noun: a place where people can play

import UIKit



//创建空字符串的两种方法
var emptyString1 = ""
var emptyString2 = String()
emptyString1 = "ok"
print(emptyString1)
print(emptyString2)





//String Literals
let someString = "Some string literal value"


//Multiline String Literals
//If you need a string that spans several lines, use a multiline string literal—a sequence of characters surrounded by three double quotation marks:
let quotation = """
The White Rabbit put on his spectacles.  "Where shall I begin,
please your Majesty?" he asked.

"Begin at the beginning," the King said gravely, "and go on
till you come to the end; then stop."
"""

print(quotation)



//When your source code includes a line break inside of a multiline string literal, that line break also appears in the string’s value. If you want to use line breaks to make your source code easier to read, but you don’t want the line breaks to be part of the string’s value, write a backslash (\) at the end of those lines:
//如果你的代码中，多行字符串字面量包含换行符的话，则多行字符串字面量中也会包含换行符。如果你想换行，以便加强代码的可读性，但是你又不想在你的多行字符串字面量中出现换行符的话，你可以用在行尾写一个反斜杠（\）作为续行符。
let softWrappedQuotation = """
The White Rabbit put on his spectacles.  "Where shall I begin, \
please your Majesty?" he asked.

"Begin at the beginning," the King said gravely, "and go on \
till you come to the end; then stop."
"""

print(softWrappedQuotation)




//To make a multiline string literal that begins or ends with a line feed, write a blank line as the first or last line. For example:
//为了让一个多行字符串字面量开始和结束于换行符，请将换行写在第一行和最后一行，例如：
let lineBreaks = """

This string starts with a line break.
It also ends with a line break.

"""
print(lineBreaks)



//一个多行字符串字面量能够缩进来匹配周围的代码。关闭引号（"""）之前的空白字符串告诉 Swift 编译器其他各行多少空白字符串需要忽略。然而，如果你在某行的前面写的空白字符串超出了关闭引号（"""）之前的空白字符串，则超出部分将被包含在多行字符串字面量中。

let linesWithIndentation = """
This line doesn't begin with whitespace.
    This line begins with four spaces.
This line doesn't with whitespace.
"""
print(linesWithIndentation)



//Because multiline string literals use three double quotation marks instead of just one, you can include a double quotation mark (") inside of a multiline string literal without escaping it.
let wiseWords = "\"Imagination is more important than knowledge\" - Einstein"//注意转意字符\的用法
print(wiseWords)
print(wiseWords.count)//如果想要获得一个字符串中 Character 值的数量，可以使用 count 属性。



//由于多行字符串字面量使用了三个双引号，而不是一个，所以你可以在多行字符串字面量里直接使用双引号（"）而不必加上转义符（\）。要在多行字符串字面量中使用 """ 的话，就需要使用至少一个转义符（\）：
let singleLineString = "These are the same."
print(singleLineString)

let multilineString = """
\"""These are the same.\"""
""" //注意转意字符\的用法
print(multilineString)

let threeDoubleQuotationMarks = """
Escaping the first quotation mark \"""
Escaping all three quotation marks \"\"\"
"""
print(threeDoubleQuotationMarks)




//Initializing an Empty String .
//To create an empty String value as the starting point for building a longer string, either assign an empty string literal to a variable, or initialize a new String instance with initializer syntax:
//初始化空字符串
//要创建一个空字符串作为初始值，可以将空的字符串字面量赋值给变量，也可以初始化一个新的 String 实例：
var emptyString = ""               // empty string literal
var anotherEmptyString = String()  // initializer syntax
// these two strings are both empty, and are equivalent to each other
//这两种字符串初始化方法的效果是一样的
//Find out whether a String value is empty by checking its Boolean isEmpty property:
if emptyString.isEmpty {
    print("Nothing to see here")
}
// Prints "Nothing to see here"
if anotherEmptyString.isEmpty{
    print("no see")
}

emptyString = "for example"
anotherEmptyString = "for example"//对字符串变量进行赋值。

//字符串可变性
//String Mutability
//You indicate whether a particular String can be modified (or mutated) by assigning it to a variable (in which case it can be modified), or to a constant (in which case it can’t be modified):
var variableString = "Horse"
variableString += " and carriage"
// variableString is now "Horse and carriage"
/*
let constantString = "Highlander"
constantString += " and another Highlander"
*/
//this reports a compile-time error - a constant string cannot be modified

//Working with Characters
//You can access the individual Character values for a String by iterating over the string with a for-in loop:

for character in "Dog!🐶" {
    print(character)
}
// D
// o
// g
// !
// 🐶


//Alternatively, you can create a stand-alone Character constant or variable from a single-character string literal by providing a Character type annotation:
//另外，通过标明一个 Character 类型并用字符字面量进行赋值，可以建立一个独立的字符常量或变量：
let exclamationMark: Character = "!"

//String values can be constructed by passing an array of Character values as an argument to its initializer:
//字符串可以通过传递一个值类型为 Character 的数组作为自变量来初始化：
let catCharacters: [Character] = ["C", "a", "t", "!", "🐱"]
print(catCharacters)//注意直接输出字符数组时的输出格式
let catString = String(catCharacters)
print(catString)
// Prints "Cat!🐱"


//连接字符串和字符
//Concatenating Strings and Characters String values can be added together (or concatenated) with the addition operator (+) to create a new String value:
let string1 = "hello"
let string2 = " there"
var welcome = string1 + string2
// welcome now equals "hello there"

//You can also append a String value to an existing String variable with the addition assignment operator (+=):
var instruction = "look over"
instruction += string2
// instruction now equals "look over there"

//You can append a Character value to a String variable with the String type’s append() method:
welcome.append(exclamationMark)
welcome.append("!")
// welcome now equals "hello there!"



//If you’re using multiline string literals to build up the lines of a longer string, you want every line in the string to end with a line break, including the last line. For example:
//如果你需要使用多行字符串字面量来拼接字符串，并且你需要字符串每一行都以换行符结尾，包括最后一行
let badStart = """
one
two
"""
let end = """
three
"""
print(badStart+end)
// Prints two lines:
// one
// twothree

let goodStart = """
one
two

"""/*two后边的空行在此相当于是换行符的作用*/
print(goodStart+end)
// Prints three lines:
// one
// two
// three



//字符串插值
//String Interpolation
//字符串插值是一种从混合常量、变量、字面量和表达式的字符串字面量构造新 String值的方法。每一个你插入到字符串字面量的元素都要被一对圆括号包裹，然后使用反斜杠前缀：
//String interpolation is a way to construct a new String value from a mix of constants, variables, literals, and expressions by including their values inside a string literal. You can use string interpolation in both single-line and multiline string literals. Each item that you insert into the string literal is wrapped in a pair of parentheses, prefixed by a backslash (\):
let multiplier = 3
let message = "\(multiplier) times 2.5 is \(Double(multiplier) * 2.5)"//此处把multiplier由整型转换为双精度型后才能和2.5一起参与运算
// message is "3 times 2.5 is 7.5"





//字符串字面量中的特殊字符
//字符串字面量能包含以下特殊字符：

//转义特殊字符 \0 (空字符)， \\ (反斜杠)， \t (水平制表符)， \n (换行符)， \r(回车符)， \" (双引号) 以及 \' (单引号)；
//任意的 Unicode 标量，写作 \u{n}，里边的 n是一个 1-8 个与合法 Unicode 码位相等的16进制数字。下边的代码展示了这些特殊字符的四个栗子。 wisewords常量包含了两个转义双引号字符。 dollarSign， blackHeart和 sparklingHeart常量展示了 Unicode 标量格式：
let wisewords = "\"Imagination is more important than knowledge\" - Einstein"
// "Imagination is more important than knowledge" - Einstein
let dollarSign = "\u{24}" // $, Unicode scalar U+0024
let blackHeart = "\u{2665}" // ♥, Unicode scalar U+2665
let sparklingHeart = "\u{1F496}" // 💖, Unicode scalar U+1F496



//可拓展的字符群集可以使包围记号（例如 COMBINING ENCLOSING CIRCLE 或者 U+20DD）的标量包围其他 Unicode 标量，作为一个单一的 Character 值：
let enclosedEAcute: Character = "\u{E9}\u{20DD}"
// enclosedEAcute is é⃝



//地域性指示符号的 Unicode 标量可以组合成一个单一的 Character 值，例如 REGIONAL INDICATOR SYMBOL LETTER U(U+1F1FA)和 REGIONAL INDICATOR SYMBOL LETTER S(U+1F1F8)：
let regionalIndicatorForUS: Character = "\u{1F1FA}\u{1F1F8}"
// regionalIndicatorForUS is 🇺🇸



//Counting Characters
//计算字符数量
//如果想要获得一个字符串中 Character 值的数量，可以使用 count 属性：
let unusualMenagerie = "Koala 🐨, Snail 🐌, Penguin 🐧, Dromedary 🐪"
print("unusualMenagerie has \(unusualMenagerie.count) characters")
// Prints "unusualMenagerie has 40 characters"


//例如，如果你用四个字符的单词 cafe 初始化一个新的字符串，然后添加一个 COMBINING ACTUE ACCENT(U+0301)作为字符串的结尾。最终这个字符串的字符数量仍然是 4，因为第四个字符是 é，而不是 e：
var word = "cafe"
print("the number of characters in \(word) is \(word.count)")
// Prints "the number of characters in cafe is 4"

word += "\u{301}"    // COMBINING ACUTE ACCENT, U+0301
print("the number of characters in \(word) is \(word.count)")
// Prints "the number of characters in café is 4"



//字符串索引
//每一个 String 值都有一个关联的索引（index）类型，String.Index，它对应着字符串中的每一个 Character 的位置。前面提到，不同的字符可能会占用不同数量的内存空间，所以要知道 Character 的确定位置，就必须从 String 开头遍历每一个 Unicode 标量直到结尾。因此，Swift 的字符串不能用整数（integer）做索引。使用 startIndex 属性可以获取一个 String 的第一个 Character 的索引。使用 endIndex 属性可以获取最后一个 Character 的后一个位置的索引。因此，endIndex 属性不能作为一个字符串的有效下标。如果 String 是空串，startIndex 和 endIndex 是相等的。通过调用 String 的 index(before:) 或 index(after:) 方法，可以立即得到前面或后面的一个索引。您还可以通过调用 index(_:offsetBy:) 方法来获取对应偏移量的索引，这种方式可以避免多次调用 index(before:) 或 index(after:) 方法。

//你可以使用下标语法来访问 String 特定索引的 Character。
let greeting = "Guten Tag!"
greeting[greeting.startIndex]
// G
greeting[greeting.index(before: greeting.endIndex)]
// !
greeting[greeting.index(after: greeting.startIndex)]
// u
let index = greeting.index(greeting.startIndex, offsetBy: 7)
greeting[index]//此句等价于greeting[greeting.index(greeting.startIndex, offsetBy: 7)]
// a
print(greeting[greeting.index(after: greeting.startIndex)])


//使用 indices 属性会创建一个包含全部索引的范围（Range），用来在一个字符串中访问单个字符。
for index in greeting.indices {
    print("\(greeting[index]) ", terminator: "")
}
// Prints "G u t e n   T a g ! "
//注意:您可以使用 startIndex 和 endIndex 属性或者 index(before:) 、index(after:) 和 index(_:offsetBy:) 方法在任意一个确认的并遵循 Collection 协议的类型里面，如上文所示是使用在 String 中，您也可以使用在 Array、Dictionary 和 Set 中。


//Inserting and Removing
//插入和删除
//调用 insert(_:at:) 方法可以在一个字符串的指定索引插入一个字符，调用 insert(contentsOf:at:) 方法可以在一个字符串的指定索引插入一个段字符串。
var Welcome = "hello"
Welcome.insert("!", at: Welcome.endIndex)
print(Welcome)
// welcome now equals "hello!"
Welcome.insert(contentsOf: " there", at: Welcome.index(before: Welcome.endIndex))
print(Welcome)
// welcome now equals "hello there!"

//To remove a single character from a string at a specified index, use the remove(at:) method, and to remove a substring at a specified range, use the removeSubrange(_:) method:
print(Welcome[Welcome.index(before: Welcome.endIndex)])
Welcome.remove(at: Welcome.index(before: Welcome.endIndex))
print(Welcome)
// welcome now equals "hello there"
let range = Welcome.index(Welcome.endIndex, offsetBy: -6)..<Welcome.endIndex
Welcome.removeSubrange(range)
print(Welcome)
// welcome now equals "hello"




//Substrings
//子字符串
//当你从字符串中获取一个子字符串 —— 例如，使用下标或者 prefix(_:) 之类的方法 —— 就可以得到一个 SubString 的实例，而非另外一个 String。Swift 里的 SubString 绝大部分函数都跟 String 一样，意味着你可以使用同样的方式去操作 SubString 和 String。然而，跟 String 不同的是，你只有在短时间内需要操作字符串时，才会使用 SubString。当你需要长时间保存结果时，就把 SubString 转化为 String 的实例：
let Greeting = "Hello, world!"
let Index = Greeting.index(of: ",") ?? Greeting.endIndex
let beginning = Greeting[..<Index]
// beginning 的值为 "Hello"

// 把结果转化为 String 以便长期存储。
let newString = String(beginning)
//就像 String，每一个 SubString 都会在内存里保存字符集。而 String 和 SubString 的区别在于性能优化上，SubString 可以重用原 String 的内存空间，或者另一个 SubString 的内存空间（String 也有同样的优化，但如果两个 String 共享内存的话，它们就会相等）。这一优化意味着你在修改 String 和 SubString 之前都不需要消耗性能去复制内存。就像前面说的那样，SubString 不适合长期存储 —— 因为它重用了原 String 的内存空间，原 String 的内存空间必须保留直到它的 SubString 不再被使用为止。上面的例子，greeting 是一个 String，意味着它在内存里有一片空间保存字符集。而由于 beginning 是 greeting 的 SubString，它重用了 greeting 的内存空间。相反，newString 是一个 String —— 它是使用 SubString 创建的，拥有一片自己的内存空间。下面的图展示了他们之间的关系：



//字符串数组的一些例子
var students = ["Ben", "Ivy", "Jordell", "Maxime"]

if let i = students.index(of: "Maxime") {
    print(i)
    students[i] = "Max"
}
print(students)
// Prints "["Ben", "Ivy", "Jordell", "Max"]"
print(students[students.index(before:students.endIndex)])
print(students[0])
print(students[1...3])



//Prefix and Suffix Equality
//前缀或后缀相等
//通过调用字符串的 hasPrefix(_:)/hasSuffix(_:) 方法来检查字符串是否拥有特定前缀/后缀，两个方法均接收一个 String 类型的参数，并返回一个布尔值。下面的例子以一个字符串数组表示莎士比亚话剧《罗密欧与朱丽叶》中前两场的场景位置：

let romeoAndJuliet = [
    "Act 1 Scene 1: Verona, A public place",
    "Act 1 Scene 2: Capulet's mansion",
    "Act 1 Scene 3: A room in Capulet's mansion",
    "Act 1 Scene 4: A street outside Capulet's mansion",
    "Act 1 Scene 5: The Great Hall in Capulet's mansion",
    "Act 2 Scene 1: Outside Capulet's mansion",
    "Act 2 Scene 2: Capulet's orchard",
    "Act 2 Scene 3: Outside Friar Lawrence's cell",
    "Act 2 Scene 4: A street in Verona",
    "Act 2 Scene 5: Capulet's mansion",
    "Act 2 Scene 6: Friar Lawrence's cell"
]
//您可以调用 hasPrefix(_:) 方法来计算话剧中第一幕的场景数：

var act1SceneCount = 0
for scene in romeoAndJuliet {
    if scene.hasPrefix("Act 1 ") {
        act1SceneCount += 1
    }
}
print("There are \(act1SceneCount) scenes in Act 1")
// 打印输出 "There are 5 scenes in Act 1"
//相似地，您可以用 hasSuffix(_:) 方法来计算发生在不同地方的场景数：

var mansionCount = 0
var cellCount = 0
for scene in romeoAndJuliet {
    if scene.hasSuffix("Capulet's mansion") {
        mansionCount += 1
    } else if scene.hasSuffix("Friar Lawrence's cell") {
        cellCount += 1
    }
}
print("\(mansionCount) mansion scenes; \(cellCount) cell scenes")
// 打印输出 "6 mansion scenes; 2 cell scenes"
//注意：hasPrefix(_:) 和 hasSuffix(_:) 方法都是在每个字符串中逐字符比较其可扩展的字符群集是否标准相等，详细描述在字符串/字符相等。











