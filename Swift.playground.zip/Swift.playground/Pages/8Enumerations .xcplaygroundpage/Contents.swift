//: Playground - noun: a place where people can play

import UIKit




//Enumerations
//枚举


//Enumeration syntax
//枚举语法

//You introduce enumerations with the enum keyword and place their entire definition within a pair of braces:
//使用 enum 关键词来创建枚举并且把它们的整个定义放在一对大括号内：
enum SomeEnumeration {
    // 枚举定义放在这里
}

//下面是用枚举表示指南针四个方向的例子：
enum CompassPoint {
    case north
    case south
    case east
    case west
}
//枚举中定义的值（如 north，south，east 和 west）是这个枚举的成员值（或成员）。你可以使用 case 关键字来定义一个新的枚举成员值。



//Multiple cases can appear on a single line, separated by commas:
//多个成员值可以出现在同一行上，用逗号隔开：
enum Planet {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
}

//Each enumeration definition defines a new type. Like other types in Swift, their names (such as CompassPoint and Planet) should start with a capital letter. Give enumeration types singular rather than plural names, so that they read as self-evident:
//每个枚举定义了一个全新的类型。像 Swift 中其他类型一样，它们的名字（例如 CompassPoint 和 Planet）应该以一个大写字母开头。给枚举类型起一个单数名字而不是复数名字，这样在阅读代码时就能取到不言而喻的作用
var directionToHead = CompassPoint.west //将枚举中的某个成员赋值给一个变量时，变量的类型会被自动推断为枚举类型。
print(directionToHead)

//The type of directionToHead is inferred when it is initialized with one of the possible values of CompassPoint. Once directionToHead is declared as a CompassPoint, you can set it to a different CompassPoint value using a shorter dot syntax:
//directionToHead 的类型可以在它被 CompassPoint 的某个值初始化时推断出来。一旦 directionToHead 被声明为 CompassPoint 类型，你可以使用更简短的点语法将其设置为另一个 CompassPoint 的值：
directionToHead = .east
//当 directionToHead 的类型已知时，再次为其赋值可以省略枚举类型名。在使用具有显式类型的枚举值时，这种写法让代码具有更好的可读性。




//Matching Enumeration Values with a Switch Statement
//使用 Switch 语句匹配枚举值
//You can match individual enumeration values with a switch statement:
//你可以使用 switch 语句匹配单个枚举值：
directionToHead = .south
//print(directionToHead)
switch directionToHead {
case .north:
    print("Lots of planets have a north")
case .south:
    print("Watch out for penguins")
case .east:
    print("Where the sun rises")
case .west:
    print("Where the skies are blue")
}
// Prints "Watch out for penguins"



//正如在控制流中介绍的那样，在判断一个枚举类型的值时，switch 语句必须穷举所有情况。如果忽略了 .west 这种情况，上面那段代码将无法通过编译，因为它没有考虑到 CompassPoint 的全部成员。强制穷举确保了枚举成员不会被意外遗漏。当不需要匹配每个枚举成员的时候，你可以提供一个 default 分支来涵盖所有未明确处理的枚举成员：
let somePlanet = Planet.earth
switch somePlanet {
case .earth:
    print("Mostly harmless")
default:
    print("Not a safe place for humans")
}
// Prints "Mostly harmless"






 
 
//Iterating over Enumeration Cases
//遍历枚举情况（case）
//For some enumerations, it’s useful to have a collection of all of that enumeration’s cases. You enable this by writing : CaseIterable after the enumeration’s name. Swift exposes a collection of all the cases as an allCases property of the enumeration type. Here’s an example:
 enum Beverage: CaseIterable {
   case coffee, tea, juice //,cocacola, pepsi 全部写在一行也对，分开写为两行像下面也对。
 //case cocacola, pepsi
 //去掉以上这句代码的注释运行后看看结果有何不可
 }

 let numberOfChoices = Beverage.allCases.count //要使用allCases属性，
 print("\(numberOfChoices) beverages available")
 // Prints "3 beverages available"
 //In the example above, you write Beverage.allCases to access a collection that contains all of the cases of the Beverage enumeration. You can use allCases like any other collection—the collection’s elements are instances of the enumeration type, so in this case they’re Beverage values. The example above counts how many cases there are, and the example below uses a for loop to iterate over all the cases.
 
 for beverage in Beverage.allCases {
 print(beverage)
 }
 // coffee
 // tea
 // juice









//Associated Values
//关联值
//关联值是创建一个基于枚举成员的常量或变量时才设置的值，枚举成员的关联值可以变化。
//上一小节的例子演示了如何定义和分类枚举的成员。你可以为 Planet.earth 设置一个常量或者变量，并在赋值之后查看这个值。然而，有时候能够把其他类型的关联值和成员值一起存储起来会很有用。这能让你连同成员值一起存储额外的自定义信息，并且你每次在代码中使用该枚举成员时，还可以修改这个关联值。你可以定义 Swift 枚举来存储任意类型的关联值，如果需要的话，每个枚举成员的关联值类型可以各不相同。枚举的这种特性跟其他语言中的可识别联合（discriminated unions），标签联合（tagged unions），或者变体（variants）相似。例如，假设一个库存跟踪系统需要利用两种不同类型的条形码来跟踪商品。有些商品上标有使用 0 到 9的数字的UPC格式的一维条形码。每一个条形码都有一个代表“数字系统”的数字，该数字后接五位代表“厂商代码”的数字，接下来是五位代表“产品代码”的数字。最后一个数字是“检查”位，用来验证代码是否被正确扫描：
//在 Swift 中，使用如下方式定义表示两种商品条形码的枚举：
enum Barcode {
    case upc(Int, Int, Int, Int)
    case qrCode(String)
}
//以上代码可以这么理解：“定义一个名为 Barcode 的枚举类型，它的一个成员值是具有元组 (Int，Int，Int，Int) 类型关联值的 upc，另一个成员值是具有 String 类型关联值的 qrCode。” 这个定义不提供任何 Int 或 String 类型的关联值，它只是定义了，当 Barcode 常量和变量等于 Barcode.upc 或 Barcode.qrCode 时，可以存储的关联值的类型。然后可以使用任意一种条形码类型创建新的条形码，例如：
var productBarcode = Barcode.upc(8, 85909, 51226, 3)//关联值是创建一个基于枚举成员的常量或变量时才设置的值，枚举成员的关联值可以变化。
//print(productBarcode)
//上面的例子创建了一个名为 productBarcode 的变量，并将 Barcode.upc 赋值给它，关联的元组值为 (8, 85909, 51226, 3)。

//同一个商品可以被分配一个不同类型的条形码，例如：
productBarcode = .qrCode("ABCDEFGHIJKLMNOP")//关联值是创建一个基于枚举成员的常量或变量时才设置的值，枚举成员的关联值可以变化。
//这时，原始的 Barcode.upc 和其整数关联值被新的 Barcode.qrCode 和其字符串关联值所替代。Barcode 类型的常量和变量可以存储一个 .upc 或者一个 .qrCode（连同它们的关联值），但是在同一时间只能存储这两个值中的一个。

//像先前那样，可以使用一个 switch 语句来检查不同的条形码类型。然而，这一次，关联值可以被提取出来作为 switch 语句的一部分。你可以在 switch 的 case 分支代码中提取每个关联值作为一个常量（用 let 前缀）或者作为一个变量（用 var 前缀）来使用：
switch productBarcode {
case .upc(let numberSystem, let manufacturer, let product, let check):
    print("UPC: \(numberSystem), \(manufacturer), \(product), \(check).")
case .qrCode(let productCode):
    print("QR code: \(productCode).")
}
// Prints "QR code: ABCDEFGHIJKLMNOP."

//如果一个枚举成员的所有关联值都被提取为常量，或者都被提取为变量，为了简洁，你可以只在成员名称前标注一个 let 或者 var：
switch productBarcode {
case let .upc(numberSystem, manufacturer, product, check):
    print("UPC : \(numberSystem), \(manufacturer), \(product), \(check).")
case let .qrCode(productCode):
    print("QR code: \(productCode).")
}
// Prints "QR code: ABCDEFGHIJKLMNOP."





//Raw Values
//原始值
//在关联值小节的条形码例子中，演示了如何声明存储不同类型关联值的枚举成员。作为关联值的替代选择，枚举成员可以被默认值（称为原始值）预填充，这些原始值的类型必须相同。这是一个使用 ASCII 码作为原始值的枚举：
enum ASCIIControlCharacter: Character {  //原始值是在定义枚举时被预先填充的值，对于一个特定的枚举成员，它的原始值始终不变。
    case tab = "\t"
    case lineFeed = "\n"
    case carriageReturn = "\r"
}
//枚举类型 ASCIIControlCharacter 的原始值类型被定义为 Character，并设置了一些比较常见的 ASCII 控制字符。原始值可以是字符串、字符，或者任意整型值或浮点型值。每个原始值在枚举声明中必须是唯一的。
//注意:原始值和关联值是不同的。原始值是在定义枚举时被预先填充的值，像上述三个 ASCII 码。对于一个特定的枚举成员，它的原始值始终不变。关联值是创建一个基于枚举成员的常量或变量时才设置的值，枚举成员的关联值可以变化。
//总结：原始值不可变，关联值可变。




//Implicitly Assigned Raw Values
//原始值的隐式赋值

//在使用原始值是整数或者字符串类型的枚举时，不需要显式地为每一个枚举成员设置原始值，Swift 将会自动为你赋值。例如，当使用整数作为原始值时，隐式赋值的值依次递增 1。如果第一个枚举成员没有设置原始值，其原始值将为 0。下面的枚举是对之前 Planet 这个枚举的一个细化，利用整型的原始值来表示每个行星在太阳系中的顺序：
enum PLanet: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune// 把这句的 = 1 去掉后就变为原始值从0开始自动赋值
}
print(PLanet.earth.rawValue)
//在上面的例子中，Plant.mercury 的显式原始值为 1，Planet.venus 的隐式原始值为 2，依次类推。


//当使用字符串作为枚举类型的原始值时，每个枚举成员的隐式原始值为该枚举成员的名称。
//下面的例子是 CompassPoint 枚举的细化，使用字符串类型的原始值来表示各个方向的名称：
enum COmpassPoint: String {
    case north, south, east, west
}
//上面例子中，COmpassPoint.south 拥有隐式原始值 south，依次类推。

//使用枚举成员的 rawValue 属性可以访问该枚举成员的原始值：
let earthsOrder = PLanet.earth.rawValue//rawValue是一个原始值属性
print(earthsOrder)
print(PLanet.earth.rawValue)
// earthsOrder is 3

let EarthsOrder = PLanet.earth
print(EarthsOrder.rawValue)




let sunsetDirection = COmpassPoint.west.rawValue//这里的sunsetDirection是一个字符串常量
print(sunsetDirection)
// sunsetDirection is "west"

let SunsetDirection = COmpassPoint.west//这里的sunsetDirection是一个枚举类型常量
print(SunsetDirection.rawValue)



//Initializing from a Raw Value
//使用原始值初始化枚举实例
//如果在定义枚举类型的时候使用了原始值，那么将会自动获得一个初始化方法，这个方法接收一个叫做 rawValue 的参数，参数类型即为原始值类型，返回值则是枚举成员或 nil。你可以使用这个初始化方法来创建一个新的枚举实例。这个例子利用原始值 7 创建了枚举成员 uranus：
let possiblePlanet = PLanet(rawValue: 7)  //开发文档里有init?(rawValue: Self.RawValue)
// possiblePlanet is of type Planet? and equals PLanet.uranus
//在上面的例子中，possiblePlanet 是 PLanet? 类型，或者说“可选的 PLanet”。
print(possiblePlanet!)// 此处要加感叹号运行才能通过

//If you try to find a planet with a position of 11, the optional Planet value returned by the raw value initializer will be nil:
//如果你试图寻找一个位置为 11 的行星，通过原始值构造器返回的可选 Planet 值将是 nil：
let positionToFind = 11
if let somePlanet = PLanet(rawValue: positionToFind)
{
    switch somePlanet
    {
    case .earth:
        print("Mostly harmless")
    default:
        print("Not a safe place for humans")
    }
}
else
{
    print("There isn't a planet at position \(positionToFind)")
}
// Prints "There isn't a planet at position 11"
//这个例子使用了可选绑定（optional binding），试图通过原始值 11 来访问一个行星。if let somePlanet = Planet(rawValue: 11) 语句创建了一个可选 Planet，如果可选 Planet 的值存在，就会赋值给 somePlanet。在这个例子中，无法检索到位置为 11 的行星，所以 else 分支被执行。




//Recursive Enumerations
//递归枚举

enum ArithmeticExpression {
    case number(Int)
    indirect case addition(ArithmeticExpression, ArithmeticExpression)
    indirect case multiplication(ArithmeticExpression, ArithmeticExpression)
}
//你也可以在枚举类型开头加上 indirect 关键字来表明它的所有成员都是可递归的：
/*
 indirect enum ArithmeticExpression {
    case number(Int)
    case addition(ArithmeticExpression, ArithmeticExpression)
    case multiplication(ArithmeticExpression, ArithmeticExpression)
}
*/


//上面定义的枚举类型可以存储三种算术表达式：纯数字、两个表达式相加、两个表达式相乘。枚举成员 addition 和 multiplication 的关联值也是算术表达式——这些关联值使得嵌套表达式成为可能。例如，表达式 (5 + 4) * 2，乘号右边是一个数字，左边则是另一个表达式。因为数据是嵌套的，因而用来存储数据的枚举类型也需要支持这种嵌套——这意味着枚举类型需要支持递归。下面的代码展示了使用 ArithmeticExpression 这个递归枚举创建表达式 (5 + 4) * 2
let five = ArithmeticExpression.number(5)
print(five)
let four = ArithmeticExpression.number(4)
let sum = ArithmeticExpression.addition(five, four)
let product = ArithmeticExpression.multiplication(sum, ArithmeticExpression.number(2))

//要操作具有递归性质的数据结构，使用递归函数是一种直截了当的方式。例如，下面是一个对算术表达式求值的函数:
func evaluate(_ expression: ArithmeticExpression) -> Int {  //这句里的 ArithmeticExpression 表示传入的函数参数是一个枚举类型
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    }
}

print(evaluate(product))
// Prints "18"



