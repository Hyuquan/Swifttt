import Foundation


protocol Container {
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}


struct Stack<Element>:Container {
    // original Stack<Element> implementation
    // Stack<Element> 的原始实现部分
    var items = [Element]()
    
    mutating func push(_ item: Element) {
        items.append(item)
    }
    
    mutating func pop() -> Element {
        return items.removeLast()
    }
    // conformance to the Container protocol
    // Container 协议的实现部分
    mutating func append(_ item: Element) {
        self.push(item)
    }
    
    var count: Int {
        return items.count
    }
    
    subscript(i: Int) -> Element {
        return items[i]
    }
}



extension Array: Container {}




//************************************************************************************************************************
//22.9
//Generic Where Clauses
//泛型 Where 语句

//类型约束让你能够为泛型函数，下标，类型的类型参数定义一些强制要求。
//为关联类型定义约束也是非常有用的。你可以在参数列表中通过 where 子句为关联类型定义约束。你能通过 where 子句要求一个关联类型遵从某个特定的协议，以及某个特定的类型参数和关联类型必须类型相同。你可以通过将 where 关键字紧跟在类型参数列表后面来定义 where 子句，where 子句后跟一个或者多个针对关联类型的约束，以及一个或多个类型参数和关联类型间的相等关系。你可以在函数体或者类型的大括号之前添加 where 子句。
//下面的例子定义了一个名为 allItemsMatch 的泛型函数，用来检查两个 Container 实例是否包含相同顺序的相同元素。如果所有的元素能够匹配，那么返回 true，否则返回 false。
//被检查的两个 Container 可以不是相同类型的容器（虽然它们可以相同），但它们必须拥有相同类型的元素。这个要求通过一个类型约束以及一个 where 子句来表示：
func allItemsMatch<C1: Container, C2: Container>(_ someContainer: C1, _ anotherContainer: C2) -> Bool
    where C1.Item == C2.Item, C1.Item: Equatable {   //你可以在函数体或者类型的大括号之前添加 where 子句。
        
        // Check that both containers contain the same number of items.
        // 检查两个容器含有相同数量的元素
        if someContainer.count != anotherContainer.count {
            return false
        }
        
        // Check each pair of items to see if they're equivalent.
        // 检查每一对元素是否相等
        for i in 0..<someContainer.count {
            if someContainer[i] != anotherContainer[i] {
                return false
            }
        }
        
        // All items match, so return true.
         // 所有元素都匹配，返回 true
        return true
}
//这个函数接受 someContainer 和 anotherContainer 两个参数。参数 someContainer 的类型为 C1，参数 anotherContainer 的类型为 C2。C1 和 C2 是容器的两个占位类型参数，函数被调用时才能确定它们的具体类型。
/*
  这个函数的类型参数列表还定义了对两个类型参数的要求：

    C1 必须符合 Container 协议（写作 C1: Container）。
    C2 必须符合 Container 协议（写作 C2: Container）。
    C1 的 Item 必须和 C2 的 Item 类型相同（写作 C1.Item == C2.Item）。
    C1 的 Item 必须符合 Equatable 协议（写作 C1.Item: Equatable）。
*/

//第一个和第二个要求在函数的类型参数列表中定义，第三个和第四个要求被定义为一个 where 子句，写在关键字 where 后面，它们也是泛型函数类型参数列表的一部分。

/*
  这些要求意味着：

    someContainer 是一个 C1 类型的容器。
    anotherContainer 是一个 C2 类型的容器。
    someContainer 和 anotherContainer 包含相同类型的元素。
    someContainer 中的元素可以通过不等于操作符（!=）来检查它们是否彼此不同。
*/
//第三个和第四个要求结合起来意味着 anotherContainer 中的元素也可以通过 != 操作符来比较，因为它们和 someContainer 中的元素类型相同。
//这些要求让 allItemsMatch(_:_:) 函数能够比较两个容器，即使它们的容器类型不同。
//allItemsMatch(_:_:) 函数首先检查两个容器是否拥有相同数量的元素，如果它们的元素数量不同，那么一定不匹配，函数就会返回 false。
//进行这项检查之后，通过 for-in 循环和半闭区间操作符（..<）来迭代每个元素，检查 someContainer 中的元素是否不等于 anotherContainer 中的对应元素。如果两个元素不相等，那么两个容器不匹配，函数返回 false。
//如果循环体结束后未发现任何不匹配的情况，表明两个容器匹配，函数返回 true。


//下面演示了 allItemsMatch(_:_:) 函数的使用：
var stackOfStrings = Stack<String>()    //stackOfStrings是栈类型。
stackOfStrings.push("uno")
stackOfStrings.push("dos")
stackOfStrings.push("tres")

var arrayOfStrings = ["uno", "dos", "tres"]   //rrayOfStrings是数组类型。

if allItemsMatch(stackOfStrings, arrayOfStrings) { //以上已经有对 Array 的扩展，使其遵从 Container 协议:extension Array: Container {}
    print("All items match.")
} else {
    print("Not all items match.")
}
// Prints "All items match."
//上面的例子创建了一个 Stack 实例来存储一些 String 值，然后将三个字符串压入栈中。这个例子还通过数组字面量创建了一个 Array 实例，数组中包含同栈中一样的三个字符串。虽然栈和数组是不同的类型，但它们都遵从 Container 协议，而且它们都包含相同类型的值。因此你可以用这两个容器作为参数来调用 allItemsMatch(_:_:) 函数。在上面的例子中，allItemsMatch(_:_:) 函数正确地显示了这两个容器中的所有元素都是相互匹配的。



//以下是一些官方文档外的举例
var stackOfStringst = Stack<Int>()
stackOfStringst.push(2)
stackOfStringst.push(22)
stackOfStringst.push(222)

var arrayOfStringst = [2, 27, 222]

if allItemsMatch(stackOfStringst, arrayOfStringst) {
    print("All items match.")
} else {
    print("Not all items match.")
}
//End
//************************************************************************************************************************







//************************************************************************************************************************
//22.10
//Extensions with a Generic Where Clause
//具有泛型 Where 子句的扩展

//你也可以使用泛型 where 子句作为扩展的一部分。基于以前的例子，下面的示例扩展了泛型 Stack 结构体，添加一个 isTop(_:) 方法。
extension Stack where Element: Equatable {
    func isTop(_ item: Element) -> Bool {
        guard let topItem = items.last else {
            return false
        }
        return topItem == item
    }
}
//这个新的 isTop(_:) 方法首先检查这个栈是不是空的，然后比较给定的元素与栈顶部的元素。如果你尝试不用泛型 where 子句，会有一个问题：在 isTop(_:) 里面使用了 == 运算符，但是 Stack 的定义没有要求它的元素是符合 Equatable 协议的，所以使用 == 运算符导致编译时错误。使用泛型 where 子句可以为扩展添加新的条件，因此只有当栈中的元素符合 Equatable 协议时，扩展才会添加 isTop(_:) 方法。

//以下是 isTop(_:) 方法的调用方式：
if stackOfStrings.isTop("tres") {
    print("Top element is tres.")
} else {
    print("Top element is something else.")
}
// Prints "Top element is tres."


/*
//如果尝试在其元素不符合 Equatable 协议的栈上调用 isTop(_:) 方法，则会收到编译时错误。
struct NotEquatable { }
var notEquatableStack = Stack<NotEquatable>()
let notEquatableValue = NotEquatable()
notEquatableStack.push(notEquatableValue)
//notEquatableStack.isTop(notEquatableValue)  // Error
*/



//你可以使用泛型 where 子句去扩展一个协议。基于以前的示例，下面的示例扩展了 Container 协议，添加一个 startsWith(_:) 方法。
extension Container where Item == Double  {
    func startsWith(_ item: Item) -> Bool {
        return count >= 1 && self[0] == item //数组本身自带count属性，同时以上已经有extension Array: Container {}的扩展。
    }
    
    func average() -> Double {
        var sum = 0.0
        for index in 0..<count {
            sum += self[index]
        }
        return sum / Double(count)//Double(count)是类型转换
    }
}
//这个 startsWith(_:) 方法首先确保容器至少有一个元素，然后检查容器中的第一个元素是否与给定的元素相等。任何符合 Container 协议的类型都可以使用这个新的 startsWith(_:) 方法，包括上面使用的栈和数组，只要容器的元素是符合 Equatable 协议的。

if [9, 9, 9].startsWith(42) {
    print("Starts with 42.")
} else {
    print("Starts with something else.")
}
// Prints "Starts with something else."



//上述示例中的泛型 where 子句要求 Item 符合协议，但也可以编写一个泛型 where 子句去要求 Item 为特定类型。例如：
//extension Container where Item == Double {
//    func average() -> Double {
//        var sum = 0.0
//        for index in 0..<count {
//            sum += self[index]
//        }
//        return sum / Double(count)//Double(count)是类型转换
//    }
//}
print([1260.0, 1200.0, 98.6, 37.0].average())
// Prints "648.9"
//此示例将一个 average() 方法添加到 Item 类型为 Double 的容器中。此方法遍历容器中的元素将其累加，并除以容器的数量计算平均值。它将数量从 Int 转换为 Double 确保能够进行浮点除法。
//就像可以在其他地方写泛型 where 子句一样，你可以在一个泛型 where 子句中包含多个条件作为扩展的一部分。用逗号分隔列表中的每个条件。
//************************************************************************************************************************



func printInfo(_ value: Any) {
    let t = type(of: value)
    print("'\(value)' of type '\(t)'")
}

let count: Int = 5
printInfo(count)
// '5' of type 'I





enum SomeEnum { case left, right }
var x = SomeEnum.left
//let x: SomeEnum? = .left
switch x {
case .left:
    print("Turn left")
case .right:
    print("Turn right")
//case nil:
//    print("Keep going straight")
}
// Prints "Turn left"






@dynamicMemberLookup
struct DynamicStruct {
    let dictionary = ["someDynamicMember": 325,
                      "someOtherMember": 787]
    subscript(dynamicMember member: String) -> Int {
        return dictionary[member] ?? 1054
    }
}

let s = DynamicStruct()

// Use dynamic member lookup.
let dynamic = s.someDynamicMember
print(dynamic)
// Prints "325"

// Call the underlying subscript directly.
let equivalent = s[dynamicMember: "someDynamicMember"]
print(dynamic == equivalent)
// Prints "true"


struct Point { var x, y: Int }

@dynamicMemberLookup
struct PassthroughWrapper<Value> {
    var value: Value
    subscript<T>(dynamicMember member: KeyPath<Value, T>) -> T {
        get { return value[keyPath: member] }
    }
}

let point = Point(x: 381, y: 431)
let wrapper = PassthroughWrapper(value: point)
print(wrapper.x)





//var optionalInteger: Int?
var optionalInteger: Optional<Int>



func f(_ any: Any) { print("Function for Any") }
func f(_ int: Int) { print("Function for Int") }
let x1 = 10
f(x1)
// Prints "Function for Int"

let y: Any = x1
f(y)
// Prints "Function for Any"

f(x1 as Any)
// Prints "Function for Any"




//Key-Path Expression
struct SomeStructure {
    var someValue: Int
}

let s1 = SomeStructure(someValue: 12)
let pathToProperty = \SomeStructure.someValue

let value = s1[keyPath: pathToProperty]
// value is 12





let x2 = [10, 3, 20, 15, 4].sorted()
    .filter { $0 > 5 }
    .map { $0 * 100 }





let threeMoreDoubleQuotationMarks = #"""
Here are three more double quotes: """
"""#



#if compiler(>=5)
print("Compiled with the Swift 5 compiler or later")
#endif
#if swift(>=4.2)
print("Compiled in Swift 4.2 mode or later")
#endif
#if compiler(>=5) && swift(<5)
print("Compiled with the Swift 5 compiler or later in a Swift mode earlier than 5")
#endif
// Prints "Compiled with the Swift 5 compiler or later"
// Prints "Compiled in Swift 4.2 mode or later"
// Prints "Compiled with the Swift 5 compiler or later in a Swift mode earlier than 5"



//*
let cast = ["Vivien", "Marlon", "Kim", "Karl"]
let list = cast.joined(separator: ", ")
//let list = cast.joined(separator: "\n")  //观察改为此句的作用有何区别
print(list)
// Prints "Vivien, Marlon, Kim, Karl"
