//: Playground - noun: a place where people can play

import UIKit

//Properties
//属性
/*
   属性将值跟特定的类、结构或枚举关联。存储属性存储常量或变量作为实例的一部分，而计算属性计算（不是存储）一个值。计算属性可以用于类、结构体和枚举，存储属性只能用于类和结构体。存储属性和计算属性通常与特定类型的实例关联。但是，属性也可以直接作用于类型本身，这种属性称为类型属性。另外，还可以定义属性观察器来监控属性值的变化，以此来触发一个自定义的操作。属性观察器可以添加到自己定义的存储属性上，也可以添加到从父类继承的属性上。
*/


//Stored Properties
//存储属性
//简单来说，一个存储属性就是存储在特定类或结构体实例里的一个常量或变量。存储属性可以是变量存储属性（用关键字 var 定义），也可以是常量存储属性（用关键字 let 定义）。
//下面的例子定义了一个名为 FixedLengthRange 的结构体，该结构体用于描述整数的范围，且这个范围值在被创建后不能被修改。
struct FixedLengthRange {
    var firstValue: Int
    let length: Int
}
var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
// the range represents integer values 0, 1, and 2
rangeOfThreeItems.firstValue = 6
// the range now represents integer values 6, 7, and 8
//FixedLengthRange 的实例包含一个名为 firstValue 的变量存储属性和一个名为 length 的常量存储属性。在上面的例子中，length 在创建实例的时候被初始化，因为它是一个常量存储属性，所以之后无法修改它的值。



//Stored Properties of Constant Structure Instances
//常量结构体的存储属性
//如果创建了一个结构体的实例并将其赋值给一个常量，则无法修改该实例的任何属性，即使有属性被声明为变量也不行：
let rangeOfFourItems = FixedLengthRange(firstValue: 0, length: 4)
// this range represents integer values 0, 1, 2, and 3
//rangeOfFourItems.firstValue = 6    //当运行这句代码时会报以下错误。
//Cannot assign to property: 'rangeOfFourItems' is a 'let' constant
// this will report an error, even though firstValue is a variable property
/*
   因为 rangeOfFourItems 被声明成了常量（用 let 关键字），即使 firstValue 是一个变量属性，也无法再修改它了。这种行为是由于结构体（struct）属于值类型。当值类型的实例被声明为常量的时候，它的所有属性也就成了常量。属于引用类型的类（class）则不一样。把一个引用类型的实例赋给一个常量后，仍然可以修改该实例的变量属性。
*/




//Lazy Stored Properties
//延迟存储属性
//延迟存储属性是指当第一次被调用的时候才会计算其初始值的属性。在属性声明前使用 lazy 来标示一个延迟存储属性。
//注意：必须将延迟存储属性声明成变量（使用 var 关键字），因为属性的初始值可能在实例构造完成之后才会得到。而常量属性在构造过程完成之前必须要有初始值，因此无法声明成延迟属性。
//延迟属性很有用，当属性的值依赖于在实例的构造过程结束后才会知道影响值的外部因素时，或者当获得属性的初始值需要复杂或大量计算时，可以只在需要的时候计算它。下面的例子使用了延迟存储属性来避免复杂类中不必要的初始化。例子中定义了 DataImporter 和 DataManager 两个类，下面是部分代码：
class DataImporter {
    /*
     DataImporter is a class to import data from an external file.
     The class is assumed to take a nontrivial amount of time to initialize.
     */
    var filename = "data.txt"
    // the DataImporter class would provide data importing functionality here
}

class DataManager {
    lazy var importer = DataImporter()
    var data = [String]()
    // the DataManager class would provide data management functionality here
}

let manager = DataManager()
manager.data.append("Some data")
manager.data.append("Some more data")
// the DataImporter instance for the importer property has not yet been created
/* DataManager 类包含一个名为 data 的存储属性，初始值是一个空的字符串（String）数组。这里没有给出全部代码，只需知道 DataManager 类的目的是管理和提供对这个字符串数组的访问即可。DataManager 的一个功能是从文件导入数据。该功能由 DataImporter 类提供，DataImporter 完成初始化需要消耗不少时间：因为它的实例在初始化时可能要打开文件，还要读取文件内容到内存。DataManager 管理数据时也可能不从文件中导入数据。所以当 DataManager 的实例被创建时，没必要创建一个 DataImporter 的实例，更明智的做法是第一次用到 DataImporter 的时候才去创建它。由于使用了 lazy，importer 属性只有在第一次被访问的时候才被创建。比如访问它的属性 fileName 时：
 */
print(manager.importer.filename)
// the DataImporter instance for the importer property has now been created
// Prints "data.txt"




//Computed Properties
//计算属性
//除存储属性外，类、结构体和枚举可以定义计算属性。计算属性不直接存储值，而是提供一个 getter 和一个可选的 setter，来间接获取和设置其他属性或变量的值。
struct Point {
    var x = 0.0, y = 0.0
}

struct Size {
    var width = 0.0, height = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set(newCenter) {
            origin.x = newCenter.x - (size.width / 2)
            origin.y = newCenter.y - (size.height / 2)
        }
    }
}

var square = Rect(origin: Point(x: 0.0, y: 0.0),size: Size(width: 10.0, height: 10.0))
let initialSquareCenter = square.center
//print("中心点坐标是(\(initialSquareCenter.x),\(initialSquareCenter.y))")//自举例
square.center = Point(x: 15.0, y: 15.0)
print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
// Prints "square.origin is now at (10.0, 10.0)"
/*这个例子定义了 3 个结构体来描述几何形状：
  Point 封装了一个 (x, y) 的坐标
  Size 封装了一个 width 和一个 height
  Rect 表示一个有原点和尺寸的矩形
  Rect 也提供了一个名为 center 的计算属性。一个矩形的中心点可以从原点（origin）和大小（size）算出，所以不需要将它以显式声明的 Point 来保存。Rect 的计算属性 center 提供了自定义的 getter 和 setter 来获取和设置矩形的中心点，就像它有一个存储属性一样。上述例子中创建了一个名为 square 的 Rect 实例，初始值原点是 (0, 0)，宽度高度都是 10。
  square 的 center 属性可以通过点运算符（square.center）来访问，这会调用该属性的 getter 来获取它的值。跟直接返回已经存在的值不同，getter 实际上通过计算然后返回一个新的 Point 来表示 square 的中心点。如代码所示，它正确返回了中心点 (5, 5)。
  center 属性之后被设置了一个新的值 (15, 15)，表示向右上方移动正方形到如下图橙色正方形所示的位置。设置属性 center 的值会调用它的 setter 来修改属性 origin 的 x 和 y 的值，从而实现移动正方形到新的位置。
*/


//Shorthand Setter Declaration
//简化 Setter 声明
//如果计算属性的 setter 没有定义表示新值的参数名，则可以使用默认名称 newValue。下面是使用了简化 setter 声明的 Rect 结构体代码：
struct AlternativeRect {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set {//之前这句代码是set(newCenter)
            origin.x = newValue.x - (size.width / 2)   //默认名称 newValue 在这里是一个语法专用名称
            origin.y = newValue.y - (size.height / 2)
        }
    }
}


//简化 getter 声明
//如果整个 getter 的函数体是一个单一的表达式，那么 getter 隐式返回这个表达式。这里是另一个版本的 Rect 结构体，此处的 getter 和 setter 应用了缩写标记：
struct CompactRect {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
         return Point(x: origin.x + (size.width / 2),//return可以省略
                  y: origin.y + (size.height / 2))
        }
        set {
            origin.x = newValue.x - (size.width / 2)
            origin.y = newValue.y - (size.height / 2)
        }
    }
}
//Omitting the return from a getter follows the same rules as omitting return from a function, as described in Functions With an Implicit Return.





//Read-Only Computed Properties
//只读计算属性
/*
   只有 getter 没有 setter 的计算属性就是只读计算属性。只读计算属性总是返回一个值，可以通过点运算符访问，但不能设置新的值。
   注意：必须使用 var 关键字定义计算属性，包括只读计算属性，因为它们的值不是固定的。let 关键字只用来声明常量属性，表示初始化后再也无法修改的值。
   只读计算属性的声明可以去掉 get 关键字和花括号：
*/
struct Cuboid {
    var width = 0.0, height = 0.0, depth = 0.0
    var volume: Double {
        //只读计算属性的声明可以去掉 get 关键字和花括号
        /*
           get {
          return width * height * depth
         }
       */
        return width * height * depth
    }
}

let fourByFiveByTwo = Cuboid(width: 4.0, height: 5.0, depth: 2.0)
print("the volume of fourByFiveByTwo is \(fourByFiveByTwo.volume)")
// Prints "the volume of fourByFiveByTwo is 40.0"
//这个例子定义了一个名为 Cuboid 的结构体，表示三维空间的立方体，包含 width、height 和 depth 属性。结构体还有一个名为 volume 的只读计算属性用来返回立方体的体积。为 volume 提供 setter 毫无意义，因为无法确定如何修改 width、height 和 depth 三者的值来匹配新的 volume。然而，Cuboid 提供一个只读计算属性来让外部用户直接获取体积是很有用的。






//Property Observers
//属性观察器
//属性观察器监控和响应属性值的变化，每次属性被设置值的时候都会调用属性观察器，即使新值和当前值相同的时候也不例外。
//你可以为除了延迟存储属性之外的其他存储属性添加属性观察器，也可以通过重写属性的方式为继承的属性（包括存储属性和计算属性）添加属性观察器。你不必为非重写的计算属性添加属性观察器，因为可以通过它的 setter 直接监控和响应值的变化。
/*
   可以为属性添加如下的一个或全部观察器：
    willSet 在新的值被设置之前调用。
    didSet 在新的值被设置之后立即调用。
   willSet 观察器会将新的属性值作为常量参数传入，在 willSet 的实现代码中可以为这个参数指定一个名称，如果不指定则参数仍然可用，这时使用默认名称 newValue 表示。
   同样，didSet 观察器会将旧的属性值作为参数传入，可以为该参数命名或者使用默认参数名 oldValue。如果在 didSet 方法中再次对该属性赋值，那么新值会覆盖旧的值。
*/
//下面是一个 willSet 和 didSet 实际运用的例子，其中定义了一个名为 StepCounter 的类，用来统计一个人步行时的总步数。这个类可以和计步器或其他日常锻炼的统计装置的输入数据配合使用。
class StepCounter
{
    var totalSteps: Int = 0
    {
        
        willSet(newTotalSteps)//写为 willSet(newValue) 也行
        {  //因为，willSet 观察器会将新的属性值作为常量参数传入，在 willSet 的实现代码中可以为这个参数指定一个名称，如果不指定则参数仍然可用，这时使用默认名称 newValue 表示。
            print("About to set totalSteps to \(newTotalSteps)")//print("About to set totalSteps to \(newValue)")
            print("totalSteps的值此时仍然是\(totalSteps)，因为didSet此时还未被调用") //此句是我自己添加用来帮助理解。
        }
        
        didSet
        {
            if totalSteps > oldValue   //默认值 oldValue 表示旧值的参数名
            {
                print("The totalSteps now is  \(totalSteps)")//此句是我自己添加用来帮助理解。
                print("Added \(totalSteps - oldValue) steps")
            }
        }
        
    }
}

let stepCounter = StepCounter()
stepCounter.totalSteps = 200
// About to set totalSteps to 200
// Added 200 steps
stepCounter.totalSteps = 360
// About to set totalSteps to 360
// Added 160 steps
stepCounter.totalSteps = 896
// About to set totalSteps to 896
// Added 536 steps
/*
   StepCounter 类定义了一个 Int 类型的属性 totalSteps，它是一个存储属性，包含 willSet 和 didSet 观察器。当 totalSteps 被设置新值的时候，它的 willSet 和 didSet 观察器都会被调用，即使新值和当前值完全相同时也会被调用。
   例子中的 willSet 观察器将表示新值的参数自定义为 newTotalSteps，这个观察器只是简单的将新的值输出。
   didSet 观察器在 totalSteps 的值改变后被调用，它把新值和旧值进行对比，如果总步数增加了，就输出一个消息表示增加了多少步。didSet 没有为旧值提供自定义名称，所以默认值 oldValue 表示旧值的参数名。
 */
 





//Property Wrappers
//属性包装器

//属性包装器在管理属性存储方式的代码和定义属性的代码之间添加了一个分隔层。例如，如果您有提供线程安全检查或将其基础数据存储在数据库中的属性，则必须在每个属性上编写该代码。使用属性包装器时，在定义包装器时编写一次管理代码，然后通过将其应用于多个属性来重用该管理代码。

//要定义属性包装器，您需要创建一个结构体，枚举或类来定义wrappedValue属性。 在下面的代码中，TwelveOrLess结构体确保包装的值始终包含小于或等于12的数字。如果您要求存储更大的数字，它会存储12。
@propertyWrapper
struct TwelveOrLess {
    private var number = 0
    var wrappedValue: Int {
        get { return number }
        set { number = min(newValue, 12) }
    }
}
//setter 确保新值始终小于12，getter 则返回存储的值。
//NOTE
//上面示例中的number声明将变量标记为private，这确保number仅在TwelveOrLess的实现中使用。 编写在其他任何地方的代码都使用wrapdValue的getter和setter访问值，并且不能直接使用number。 有关 private 的说明，请参阅 Access Control。

//通过将包装器的名称作为属性写在属性名之前，可以将包装器应用于属性。这是一个存储一个小矩形的结构，使用的定义与TwelveOrLess属性封装器所实现的“ small”相同（相当随意）：

struct SmallRectangle {
    @TwelveOrLess var height: Int
    @TwelveOrLess var width: Int
}

var rectangle = SmallRectangle()
print(rectangle.height)
// Prints "0"

rectangle.height = 10
print(rectangle.height)
// Prints "10"

rectangle.height = 24
print(rectangle.height)
// Prints "12"

//height和width属性从TwelveOrLess的定义获取其初始值，该定义将TwelveOrLess.number设置为零。将数字10存储到 rectangle.height中能成功，因为它是一个小的数字。尝试存储24时实际上存储的值是12，因为24对于属性设置器设定的规则来说太大了。

//当您将包装器应用于属性时，编译器将合成为包装器提供存储的代码和通过包装器访问属性的代码。 (属性包装器负责存储包装后的值，因此没有合成的代码。)您可以编写具有属性包装器功能行为的代码，而无需使用特有的属性语法。例如，这是先前代码清单中的SmallRectangle2版本，该版本将其属性明确地包装在TwelveOrLess结构中，而不是将@TwelveOrLess作为属性写在属性名之前。
struct SmallRectangle2 {
    private var _height = TwelveOrLess()
    private var _width = TwelveOrLess()
    var height: Int {
        get { return _height.wrappedValue }
        set { _height.wrappedValue = newValue }
    }
    
    var width: Int {
        get { return _width.wrappedValue }
        set { _width.wrappedValue = newValue }
    }
}
//_height和_width属性，存储属性包装器 TwelveOrLess 的实例。高度和宽度的getter和setter包装对wrappedValue属性的访问。

//以下是自举例
var rectangle2 = SmallRectangle2()
print(rectangle2.height)
// Prints "0"

rectangle2.height = 7
print(rectangle2.height)
// Prints "7"

rectangle2.height = 22
print(rectangle2.height)
// Prints "12"
//以上是自举例



//Setting Initial Values for Wrapped Properties
//设置包装属性的初始值

//上面示例中的代码通过在TwelveOrLess的定义中给number一个初始值来设置包装属性的初始值。使用此属性包装器的代码无法为TwelveOrLess所包装的属性指定其他初始值，例如，在定义SmallRectangle时不能给height或width设置初始值。为了支持设置初始值或其他自定义，属性包装器需要添加一个初始化器。这是TwelveOrLess的扩展版本，称为SmallNumber，它定义了设置包装值和最大值的初始化器：
@propertyWrapper
struct SmallNumber {
    private var maximum: Int
    private var number: Int

    var wrappedValue: Int {
        get { return number }
        set { number = min(newValue, maximum) }
    }

    init() {
        maximum = 12
        number = 0
    }
    
    init(wrappedValue: Int) {
        maximum = 12
        number = min(wrappedValue, maximum)
    }
    
    init(wrappedValue: Int, maximum: Int) {
        self.maximum = maximum
        number = min(wrappedValue, maximum)
    }
    
}
//SmallNumber属性包装器的定义包括三个初始化器：init（），init（wrappedValue :)和init（wrappedValue：maximum :)，下面的示例用于设置包装值和最大值。有关初始化和初始化器的信息，请参见Initialization。

//在将包装器应用于属性时，如果您未指定初始值，则Swift会使用init（）初始化器来设置包装器。 例如：
struct ZeroRectangle {
    @SmallNumber var height: Int
    @SmallNumber var width: Int
}

var zeroRectangle = ZeroRectangle()
print(zeroRectangle.height, zeroRectangle.width)
// Prints "0 0"
//包装height和width的SmallNumber实例是通过调用SmallNumber（）创建的。初始化器中的代码使用默认值0和12设置初始包装值和初始最大值。属性包装器仍然提供所有初始值，就像之前在SmallRectangle中使用TwelveOrLess的示例一样。但与该示例不同的是，SmallNumber还支持编写这些初始值，作为声明属性的一部分。


//当您为属性指定初始值时，Swift使用init（wrappedValue :)初始化器来设置包装器。 例如：
struct UnitRectangle {
    @SmallNumber var height: Int = 1
    @SmallNumber var width: Int = 1
}

var unitRectangle = UnitRectangle()
print(unitRectangle.height, unitRectangle.width)
// Prints "1 1"
//当您在具有包装器的属性上写入=1时，它将转换为对init（wrappedValue:)初始化器的调用。包装height和width的SmallNumber实例是通过调用SmallNumber（wrappedValue：1）创建的。初始化器使用这里指定的包装值，并且使用默认的最大值12。



//在括号中的自定义属性后写入参数时，Swift将使用接受这些参数的初始化器来设置包装器。例如，如果您提供一个初始值和一个最大值，Swift会使用init（wrappedValue：maximum :)初始化器：
struct NarrowRectangle {
    @SmallNumber(wrappedValue: 2, maximum: 5) var height: Int
    @SmallNumber(wrappedValue: 3, maximum: 4) var width: Int
}

var narrowRectangle = NarrowRectangle()
print(narrowRectangle.height, narrowRectangle.width)
// Prints "2 3"

narrowRectangle.height = 100
narrowRectangle.width = 100
print(narrowRectangle.height, narrowRectangle.width)
// Prints "5 4"
//包装height的SmallNumber实例是通过调用SmallNumber（wrappedValue：2，maximum：5）创建的，包装width的SmallNumber实例是通过调用SmallNumber（wrappedValue：3，maximum：4）创建的。

//通过为属性包装器添加参数，您可以在包装器中设置初始状态，或者在创建包装器时将其他选项传递给包装器。此语法是使用属性包装器的最通用方法。您可以为属性提供所需的任何参数，然后将它们传递给初始化器。

//当包含属性包装器参数时，还可以使用赋值指定初始值。Swift将赋值视为wrappedValue参数，并使用接受您所包含参数的初始化器。 例如：
struct MixedRectangle {
    @SmallNumber var height: Int = 1
    @SmallNumber(maximum: 9) var width: Int = 2
}

var mixedRectangle = MixedRectangle()
print(mixedRectangle.height)
// Prints "1"

mixedRectangle.height = 20
print(mixedRectangle.height)
// Prints "12"
//包装height的SmallNumber实例是通过调用SmallNumber（wrappedValue：1）创建的，该实例使用默认的最大值12。包装width的SmallNumber实例是通过调用SmallNumber（wrappedValue：2，maximum：9）创建的。

//以下是自举例
print(mixedRectangle.width)
// Prints "2"

mixedRectangle.width = 20
print(mixedRectangle.width)
//以上是自举例








//Projecting a Value From a Property Wrapper
//从属性包装器映射值

//除了包装的值之外，属性包装器还可以通过定义投影值来公开其他功能。例如，管理对数据库的访问的属性包装器可以在其投影值上公开flushDatabaseConnection（）方法。投影值的名称与包装值相同，只是它以美元符号（$）开头。由于您的代码无法定义以$开头的属性，因此投影值永远不会干扰您定义的属性。

//在上面的SmallNumber示例中，如果您尝试将属性设置为太大的数字，则属性包装器会在存储该数字之前对其进行调整。下面的代码将一个projectedValue属性添加到SmallNumber2结构中，以跟踪存储属性的包装器在存储新值之前是否调整了该新值。

@propertyWrapper
struct SmallNumber2
{
    private var number = 0
    var projectedValue = false
    var wrappedValue: Int
    {
        get
        {
            return number
        }
        set
        {
            if newValue > 12
            {
                number = 12
                projectedValue = true
            }
            else
            {
                number = newValue
                projectedValue = false
            }
        }
    }
}


struct SomeStructure2 {
    @SmallNumber2 var someNumber: Int
}


var someStructure = SomeStructure2()

someStructure.someNumber = 4
print(someStructure.$someNumber)//投影值的名称与包装值相同，只是它以美元符号（$）开头。
//由于您的代码无法定义以$开头的属性，因此投影值永远不会干扰您定义的属性。
// Prints "false"

someStructure.someNumber = 55
print(someStructure.$someNumber)
// Prints "true"

//编写someStructure.$someNumber可以访问包装器的投影值。在存储了像4这样的小数字之后，someStructure.$someNumber的值为false。 但是，在尝试存储太大的数字（如55）后，投影值则变为true。

//属性包装器可以返回任何类型的值作为其投影值。在此示例中，属性包装器仅公开一条信息（即：数字是否已调整），因此它公开该布尔值作为其投影值。需要公开更多信息的包装器可以返回某个其他数据类型的实例，或者可以返回self以将包装器的实例作为其投影值公开。




//当您从属于该类型的一部分的代码（例如属性的 getter或实例方法）访问投影值时，可以在属性名称之前省略“self.”， 就像访问其他属性一样。以下示例中的代码将包装器围绕height和width的投影值引用为$height和$width：
enum Size1 {
    case small, large
}

struct SizedRectangle {
    @SmallNumber2 var height: Int
    @SmallNumber2 var width: Int

    mutating func resize(to size: Size1) -> Bool {// mutating表示在实例方法中修改值类型
        switch size {
        case .small:
            height = 10 //可以改变一下这些值来观察程序运行的不同情况
            width = 20  //可以改变一下这些值来观察程序运行的不同情况
        case .large:
            height = 100  //可以改变一下这些值来观察程序运行的不同情况
            width = 100    //可以改变一下这些值来观察程序运行的不同情况
        }
        return $height || $width
    }
}
//因为属性包装器语法只是具有getter和setter的属性的语法糖，所以访问height和width的行为与访问任何其他属性的行为相同。例如，resize（to :)中的代码使用其属性包装器访问height和width。
// If you call resize(to: .large), the switch case for .large sets the rectangle’s height and width to 100. The wrapper prevents the value of those properties from being larger than 12, and it sets the projected value to true, to record the fact that it adjusted their values. At the end of resize(to:), the return statement checks $height and $width to determine whether the property wrapper adjusted either height or width.



//以下是自举例
var tt = Size1.large  //创建一个枚举实例
var strtt = SizedRectangle()  //创建一个结构体实例
print(strtt.resize(to: tt))
print(strtt.height,strtt.width)



tt = .small
print(strtt.resize(to: tt))
print(strtt.height,strtt.width)
//以上是自举例





//Type Property Syntax
//类型属性语法
//在 C 或 Objective-C 中，与某个类型关联的静态常量和静态变量，是作为全局（global）静态变量定义的。但是在 Swift 中，类型属性是作为类型定义的一部分写在类型最外层的花括号内，因此它的作用范围也就在类型支持的范围内。
//使用关键字 static 来定义类型属性。在为类定义计算型类型属性时，可以改用关键字 class 来支持子类对父类的实现进行重写。下面的例子演示了存储型和计算型类型属性的语法：
struct SomeStructure {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 1
    }
}

enum SomeEnumeration {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

class SomeClass {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }
    class var overrideableComputedTypeProperty: Int {  //在为类定义计算型类型属性时，可以改用关键字 class 来支持子类对父类的实现进行重写。
        return 107
    }
}
//注意：例子中的计算型类型属性是只读的，但也可以定义可读可写的计算型类型属性，跟计算型实例属性的语法相同。

//Querying and Setting Type Properties
//获取和设置类型属性的值
//跟实例属性一样，类型属性也是通过点运算符来访问。但是，类型属性是通过类型本身来访问，而不是通过实例。比如：
print(SomeStructure.storedTypeProperty)
// Prints "Some value."
SomeStructure.storedTypeProperty = "Another value."
print(SomeStructure.storedTypeProperty)
// Prints "Another value."
print(SomeEnumeration.computedTypeProperty)
// Prints "6"
print(SomeClass.computedTypeProperty)
// Prints "27"
//注意：不同于存储实例属性，你必须总是给存储类型属性一个默认值。这是因为类型本身不能拥有能够在初始化时给存储类型属性赋值的初始化器。存储类型属性是在它们第一次访问时延迟初始化的。它们保证只会初始化一次，就算被多个线程同时访问，他们也不需要使用 lazy 修饰符标记。




//下面的例子定义了一个结构体，使用两个存储型类型属性来表示两个声道的音量，每个声道具有 0 到 10 之间的整数音量。
//官方文档中有图展示了如何把两个声道结合来模拟立体声的音量。当声道的音量是 0，没有一个灯会亮；当声道的音量是 10，所有灯点亮。本图中，左声道的音量是 9，右声道的音量是 7：

struct AudioChannel
{
    static let thresholdLevel = 10
    static var maxInputLevelForAllChannels = 0
    var currentLevel: Int = 0
    {
        didSet
             {
               if currentLevel > AudioChannel.thresholdLevel
                 {
                   // cap the new audio level to the threshold level
                   currentLevel = AudioChannel.thresholdLevel
                 }
               if currentLevel > AudioChannel.maxInputLevelForAllChannels
                 {
                  // store this as the new overall maximum input level
                  AudioChannel.maxInputLevelForAllChannels = currentLevel
                 }
             }
    }
}

//可以使用结构体 AudioChannel 创建两个声道 leftChannel 和 rightChannel，用以表示立体声系统的音量：
var leftChannel = AudioChannel()
var rightChannel = AudioChannel()

//如果将左声道的 currentLevel 设置成 7，类型属性 maxInputLevelForAllChannels 也会更新成 7：
leftChannel.currentLevel = 7
print(leftChannel.currentLevel)
// Prints "7"
print(AudioChannel.maxInputLevelForAllChannels)
// Prints "7"

//如果试图将右声道的 currentLevel 设置成 11，它会被修正到最大值 10，同时 maxInputLevelForAllChannels 的值也会更新到 10：
rightChannel.currentLevel = 11
print(rightChannel.currentLevel)
// Prints "10"
print(AudioChannel.maxInputLevelForAllChannels)
// Prints "10"

/*
   结构 AudioChannel 定义了 2 个存储型类型属性来实现上述功能。第一个是 thresholdLevel，表示音量的最大上限阈值，它是一个值为 10 的常量，对所有实例都可见，如果音量高于 10，则取最大上限值 10（见后面描述）。
 
   第二个类型属性是变量存储型属性 maxInputLevelForAllChannels，它用来表示所有 AudioChannel 实例的最大音量，初始值是 0。
 
 AudioChannel 也定义了一个名为 currentLevel 的存储型实例属性，表示当前声道现在的音量，取值为 0 到 10。
 
   属性 currentLevel 包含 didSet 属性观察器来检查每次设置后的属性值，它做如下两个检查：
 
   如果 currentLevel 的新值大于允许的阈值 thresholdLevel，属性观察器将 currentLevel 的值限定为阈值 thresholdLevel。
 如果修正后的 currentLevel 值大于静态类型属性 maxInputLevelForAllChannels 的值，属性观察器就将新值保存在 maxInputLevelForAllChannels 中。
   注意：在第一个检查过程中，didSet 属性观察器将 currentLevel 设置成了不同的值，但这不会造成属性观察器被再次调用。
 可以使用结构体 AudioChannel 创建两个声道 leftChannel 和 rightChannel，用以表示立体声系统的音量：
 */













