//Nested Types
//嵌套类型

//Enumerations are often created to support a specific class or structure’s functionality. Similarly, it can be convenient to define utility classes and structures purely for use within the context of a more complex type. To accomplish this, Swift enables you to define nested types, whereby you nest supporting enumerations, classes, and structures within the definition of the type they support.
//To nest a type within another type, write its definition within the outer braces of the type it supports. Types can be nested to as many levels as are required.
//枚举常被用于为特定类或结构体实现某些功能。类似地，枚举可以方便的定义工具类或结构体，从而为某个复杂的类型所使用。为了实现这种功能，Swift 允许你定义嵌套类型，可以在支持的类型中定义嵌套的枚举、类和结构体。
//要在一个类型中嵌套另一个类型，将嵌套类型的定义写在其外部类型的 {} 内，而且可以根据需要定义多级嵌套。



//************************************************************************************************************************
//19.1
//Nested Types in Action
//嵌套类型实践



struct BlackjackCard {
    // nested Suit enumeration
    enum Suit: Character {
        case spades = "♠", hearts = "♡", diamonds = "♢", clubs = "♣"
    }
    // nested Rank enumeration
    enum Rank: Int {
        case two = 2, three, four, five, six, seven, eight, nine, ten//涉及枚举部分的原始值的隐式赋值知识点
        case jack, queen, king, ace
       
        struct Values {//Rank 枚举中定义了一个内嵌结构体 Values 。这个结构体封装了大多牌只有一个值，而 Ace 可以有两个值这一事实。
            let first: Int, second: Int?
        }
       
        var values: Values {//Rank defines a computed property, values, which returns an instance of the Values structure.
            switch self {//?
            case .ace://等价于此句-Rank.ace:
                return Values(first: 1, second: 11)
            case .jack, .queen, .king:
                return Values(first: 10, second: nil)
            default:
                return Values(first: self.rawValue, second: nil)//涉及枚举部分的原始值的隐式赋值知识点
            }
        }
    }
    // BlackjackCard properties and methods
    let rank: Rank, suit: Suit
    var description: String {//The BlackjackCard structure defines a computed property called description, which uses the values stored in rank and suit to build a description of the name and value of the card.
        var output = "suit is \(suit.rawValue),"  //var output: String
        output += " value is \(rank.values.first)"
        if let second = rank.values.second {
            output += " or \(second)"
        }
        return output
    }
}



let theAceOfSpades = BlackjackCard(rank: .ace, suit: .spades)//涉及枚举的定义知识点
print("theAceOfSpades: \(theAceOfSpades.description)")
// Prints "theAceOfSpades: suit is ♠, value is 1 or 11"

//************************************************************************************************************************





//************************************************************************************************************************
//19.2
//Referring to Nested Types
//引用嵌套类型

//To use a nested type outside of its definition context, prefix its name with the name of the type it is nested within:
//在外部引用嵌套类型时，在嵌套类型的类型名前加上其外部类型的类型名作为前缀：
//let heartsSymbol = BlackjackCard.Suit.hearts.rawValue
let heartsSymbol = BlackjackCard.Suit.hearts.rawValue
print(heartsSymbol)
// heartsSymbol is "♡"
//For the example above, this enables the names of Suit, Rank, and Values to be kept deliberately short, because their names are naturally qualified by the context in which they are defined.
//对于上面这个例子，这样可以使 Suit、Rank 和 Values 的名字尽可能的短，因为它们的名字可以由定义它们的上下文来限定。
//************************************************************************************************************************



