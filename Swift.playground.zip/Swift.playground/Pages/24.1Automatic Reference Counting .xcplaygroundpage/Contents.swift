import Foundation

//Automatic Reference Counting
//自动引用计数



//Swift 使用自动引用计数（ARC）机制来跟踪和管理你的应用程序的内存。通常情况下，Swift 内存管理机制会一直起作用，你无须自己来考虑内存的管理。ARC 会在类的实例不再被使用时，自动释放其占用的内存。
//然而在少数情况下，为了能帮助你管理内存，ARC 需要更多的，代码之间关系的信息。本章描述了这些情况，并且为你示范怎样才能使 ARC 来管理你的应用程序的所有内存。在 Swift 使用 ARC 与在 Obejctive-C 中使用 ARC 非常类似，具体请参考过渡到 ARC 的发布说明
//引用计数仅仅应用于类的实例。结构体和枚举类型是值类型，不是引用类型，也不是通过引用的方式存储和传递。





//*****************************************************************************************************************
//23.1
//How ARC Works
//自动引用计数的工作机制

//当你每次创建一个类的新的实例的时候，ARC 会分配一块内存来储存该实例信息。内存中会包含实例的类型信息，以及这个实例所有相关的存储型属性的值。
//此外，当实例不再被使用时，ARC 释放实例所占用的内存，并让释放的内存能挪作他用。这确保了不再被使用的实例，不会一直占用内存空间。
//然而，当 ARC 收回和释放了正在被使用中的实例，该实例的属性和方法将不能再被访问和调用。实际上，如果你试图访问这个实例，你的应用程序很可能会崩溃。
//为了确保使用中的实例不会被销毁，ARC 会跟踪和计算每一个实例正在被多少属性，常量和变量所引用。哪怕实例的引用数为1，ARC 都不会销毁这个实例。
//为了使上述成为可能，无论你将实例赋值给属性、常量或变量，它们都会创建此实例的强引用。之所以称之为“强”引用，是因为它会将实例牢牢地保持住，只要强引用还在，实例是不允许被销毁的。
//*****************************************************************************************************************





//*****************************************************************************************************************
//23.2
//ARC in Action
//自动引用计数实践

//下面的例子展示了自动引用计数的工作机制。例子以一个简单的 Person 类开始，并定义了一个叫 name 的常量属性：
class Persons {
    let name: String
    init(name: String) {
        self.name = name
        print("\(name) is being initialized")
    }
    deinit {                                      //deinit 析构函数可以省略，在这里写出来是为了方便理解整个函数的逻辑。
        print("\(name) is being deinitialized")
    }
}
//Person 类有一个构造函数，此构造函数为实例的 name 属性赋值，并打印一条消息以表明初始化过程生效。Person 类也拥有一个析构函数，这个析构函数会在实例被销毁时打印一条消息。

//接下来的代码片段定义了三个类型为 Person? 的变量，用来按照代码片段中的顺序，为新的 Person 实例建立多个引用。由于这些变量是被定义为可选类型（Person?，而不是 Person），它们的值会被自动初始化为 nil，目前还不会引用到 Person 类的实例。
var reference1: Persons?
var reference2: Persons?
var reference3: Persons?

//现在你可以创建 Person 类的新实例，并且将它赋值给三个变量中的一个：
reference1 = Persons(name: "John Appleseed")
// Prints "John Appleseed is being initialized"
//应当注意到当你调用 Person 类的构造函数的时候，"John Appleseed is being initialized" 会被打印出来。由此可以确定构造函数被执行。
//由于 Person 类的新实例被赋值给了 reference1 变量，所以 reference1 到 Person 类的新实例之间建立了一个强引用。正是因为这一个强引用，ARC 会保证 Person 实例被保持在内存中不被销毁。

//如果你将同一个 Person 实例也赋值给其他两个变量，该实例又会多出两个强引用：
reference2 = reference1
reference3 = reference1
//现在这一个 Person 实例已经有三个强引用了。

//如果你通过给其中两个变量赋值 nil 的方式断开两个强引用（包括最先的那个强引用），只留下一个强引用，Person 实例不会被销毁：
reference1 = nil
reference2 = nil

//在你清楚地表明不再使用这个 Person 实例时，即第三个也就是最后一个强引用被断开时，ARC 会销毁它：
reference3 = nil
// Prints "John Appleseed is being deinitialized"
//*****************************************************************************************************************








//*****************************************************************************************************************
//23.3
//Strong Reference Cycles Between Class Instances
//类实例之间的循环强引用

//在上面的例子中，ARC 会跟踪你所新创建的 Person 实例的引用数量，并且会在 Person 实例不再被需要时销毁它。
//然而，我们可能会写出一个类实例的强引用数永远不能变成0的代码。如果两个类实例互相持有对方的强引用，因而每个实例都让对方一直存在，这种情况就是所谓的循环强引用。
//你可以通过定义类之间的关系为弱引用或无主引用，以替代强引用，从而解决循环强引用的问题。具体的过程在解决类实例之间的循环强引用中有描述。不管怎样，在你学习怎样解决循环强引用之前，很有必要了解一下它是怎样产生的。
//下面展示了一个不经意产生循环强引用的例子。例子定义了两个类：Person 和 Apartment，用来建模公寓和它其中的居民：
class Person {
    let name: String
    init(name: String) { self.name = name }
    var apartment: Apartment?
    deinit { print("\(name) is being deinitialized") }
}

class Apartment {
    let unit: String
    init(unit: String) { self.unit = unit }
    var tenant: Person?
    deinit { print("Apartment \(unit) is being deinitialized") }
}
//每一个 Person 实例有一个类型为 String，名字为 name 的属性，并有一个可选的初始化为 nil 的 apartment 属性。apartment 属性是可选的，因为一个人并不总是拥有公寓。
//类似的，每个 Apartment 实例有一个叫 unit，类型为 String 的属性，并有一个可选的初始化为 nil 的 tenant 属性。tenant 属性是可选的，因为一栋公寓并不总是有居民。
//这两个类都定义了析构函数，用以在类实例被析构的时候输出信息。这让你能够知晓 Person 和 Apartment 的实例是否像预期的那样被销毁。


//接下来的代码片段定义了两个可选类型的变量 john 和 unit4A，并分别被设定为下面的 Person 和 Apartment  的实例。鉴于可选类型的特点，这两个变量都被初始化为 nil。
var john: Person?
var unit4A: Apartment?


//现在你可以创建特定的 Person 和 Apartment 实例并将赋值给 john 和 unit4A 变量：
john = Person(name: "John Appleseed")
unit4A = Apartment(unit: "4A")

//接下来剩余部分必须要参考官方文档图例讲解来帮助理解

//*****************************************************************************************************************







