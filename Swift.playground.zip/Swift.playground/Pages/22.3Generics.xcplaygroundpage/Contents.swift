import Foundation


protocol Container {
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}



//下面是先前的非泛型的 IntStack 类型，这一版本采纳并符合了 Container 协议：
struct IntStack: Container {
    // original IntStack implementation
    // IntStack 的原始实现部分
    var items = [Int]()
    mutating func push(_ item: Int) {
        items.append(item)
    }
    mutating func pop() -> Int {
        return items.removeLast()
    }
    
    
    // conformance to the Container protocol
    // Container 协议的实现部分
    typealias Item = Int//此行可以省略
    mutating func append(_ item: Int) {
        self.push(item)
    }
    var count: Int {
        return items.count
    }
    subscript(i: Int) -> Int {
        return items[i]
    }
}



//你也可以让泛型 Stack 结构体遵从 Container 协议：
struct Stack<Element>:Container {
    // original Stack<Element> implementation
    // Stack<Element> 的原始实现部分
    var items = [Element]()
    
    mutating func push(_ item: Element) {
        items.append(item)
    }
    
    mutating func pop() -> Element {
        return items.removeLast()
    }
    // conformance to the Container protocol
    // Container 协议的实现部分
    mutating func append(_ item: Element) {
        self.push(item)
    }
    
    var count: Int {
        return items.count
    }
    
    subscript(i: Int) -> Element {
        return items[i]
    }
}





//Extending an Existing Type to Specify an Associated Type
//通过扩展一个存在的类型来指定关联类型
//”通过扩展添加协议一致性“中描述了如何利用扩展让一个已存在的类型符合一个协议，这包括使用了关联类型的协议。
//Swift 的 Array 类型已经提供 append(_:) 方法，一个 count 属性，以及一个接受 Int 类型索引值的下标用以检索其元素。这三个功能都符合 Container 协议的要求，也就意味着你只需简单地声明 Array 采纳该协议就可以扩展 Array，使其遵从 Container 协议。你可以通过一个空扩展来实现这点，正如通过扩展采纳协议中的描述：
extension Array: Container {}
//如同上面的泛型 Stack 结构体一样，Array 的 append(_:) 方法和下标确保了 Swift 可以推断出 Item 的类型。定义了这个扩展后，你可以将任意 Array 当作 Container 来使用。






//Using a Protocol in Its Associated Type’s Constraints
//在关联类型约束里使用协议

//协议可以作为它自身的要求出现。例如，这里有一个协议细化了 Container 协议，添加了一个 suffix(_:) 方法。suffix(_:) 方法返回容器中从后往前给定数量的元素，把它们存储在一个 Suffix 类型的实例里。
protocol SuffixableContainer: Container {//涉及协议的继承知识点
    associatedtype Suffix: SuffixableContainer where Suffix.Item == Item  //associatedtype Item
    func suffix(_ size: Int) -> Suffix//这里的Suffix是一个关联类型
}
//在这个协议里，Suffix 是一个关联类型，就像上边例子中 Container 的 Item 类型一样。Suffix 拥有两个约束：它必须遵循 SuffixableContainer 协议（就是当前定义的协议），以及它的 Item 类型必须是和容器里的 Item 类型相同。Item 的约束是一个 where 分句，它在下面带有泛型 Where 分句的扩展中有讨论。



//这里有一个来自闭包的循环强引用的 Stack 类型的扩展，它添加了对 SuffixableContainer 协议的遵循：
extension Stack: SuffixableContainer {
    func suffix(_ size: Int) -> Stack
    {   //此函数满足了对 SuffixableContainer 协议的遵循
        var result = Stack()//新创建一个Stack对象，用来保存此函数的返回类型。var result: Stack<Element>
        for index in (count-size)..<count {
            result.append(self[index])//这里的self表示下边创建的stackOfInts这个实例，通过下标来取得对应的值。
        }
        return result //var result: Stack<Element>
    }
    // Inferred that Suffix is Stack.
}


var stackOfInts = Stack<Int>()
stackOfInts.append(10)
stackOfInts.append(20)
stackOfInts.append(30)
let suffix = stackOfInts.suffix(2)
// suffix contains 20 and 30

//在上面的例子中，Suffix 是 Stack 的关联类型，也就是 Stack ，所以 Stack 的后缀运算返回另一个 Stack 。另外，遵循 SuffixableContainer 的类型可以拥有一个与它自己不同的 Suffix 类型——也就是说后缀运算可以返回不同的类型。比如说，这里有一个非泛型 IntStack 类型的扩展，它添加了 SuffixableContainer 遵循，使用 Stack<Int> 作为它的后缀类型而不是 IntStack：
extension IntStack: SuffixableContainer {
    func suffix(_ size: Int) -> Stack<Int>//此函数满足了对 SuffixableContainer 协议的遵循
    {//SuffixableContainer 会推断出关联值Suffix的类型是Stack<Int>
        var result = Stack<Int>()
        for index in (count-size)..<count {
            result.append(self[index])
        }
        return result
    }
    // Inferred that Suffix is Stack<Int>.
    
}

//************************************************************************************************************************








