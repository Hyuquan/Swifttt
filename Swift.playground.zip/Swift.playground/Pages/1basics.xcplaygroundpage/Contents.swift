//: Playground - noun: a place where people can play

import UIKit

//Basics

var str = "Hello, playground"



let maximumNumberOfLoginAttempts = 10
var currentLoginAttempt = 0
//定义常量和变量的方法


var x = 0.0, y = 0.0, z = 0.0  //You can declare multiple constants or multiple variables on a single line, separated by commas:


var welcomeMessage: String = "Hello" // 变量的类型声明


//You can define multiple related variables of the same type on a single line, separated by commas, with a single type annotation after the final variable name:
var red, green, blue: Double?


//Constant and variable names can contain almost any character, including Unicode characters:
let π = 3.14159
let 你好 = "你好世界"
let 🐶🐮 = "dogcow"


//You can change the value of an existing variable to another value of a compatible type. In this example, the value of friendlyWelcome is changed from "Hello!" to "Bonjour!":
var friendlyWelcome = "Hello!"
friendlyWelcome = "Bonjour!"   // "Bonjour!" 是法语早上好的意思。


//You can print the current value of a constant or variable with the print(_:separator:terminator:) function:
print(friendlyWelcome)
// Prints "Bonjour!"



//Swift 用字符串插值（string interpolation）的方式把常量名或者变量名当做占位符加入到长字符串中，Swift 会用当前常量或变量的值替换这些占位符。将常量或变量名放入圆括号中，并在开括号前使用反斜杠将其转义：
print("The current value of friendlyWelcome is \(friendlyWelcome)")
// Prints "The current value of friendlyWelcome is Bonjour!"


//Unlike many other languages, Swift doesn’t require you to write a semicolon (;) after each statement in your code, although you can do so if you wish. However, semicolons are required if you want to write multiple separate statements on a single line:
let cat = "🐱"; print(cat)
// Prints "🐱"


//you can access the minimum and maximum values of each integer type with its min and max properties:
let minValue = UInt8.min  // minValue is equal to 0, and is of type UInt8
let maxValue = UInt8.max  // maxValue is equal to 255, and is of type UInt8


//For example, if you assign a literal value of 42 to a new constant without saying what type it is, Swift infers that you want the constant to be an Int, because you have initialized it with a number that looks like an integer:
let meaningOfLife = 42
// meaningOfLife is inferred to be of type Int
//Likewise, if you don’t specify a type for a floating-point literal, Swift infers that you want to create a Double:

let pi = 3.14159
// pi is inferred to be of type Double
//Swift always chooses Double (rather than Float) when inferring the type of floating-point numbers.

//If you combine integer and floating-point literals in an expression, a type of Double will be inferred from the context:
let anotherPi = 3 + 0.14159
// anotherPi is also inferred to be of type Double


//To convert one specific number type to another, you initialize a new number of the desired type with the existing value. In the example below, the constant twoThousand is of type UInt16, whereas the constant one is of type UInt8. They can’t be added together directly, because they’re not of the same type. Instead, this example calls UInt16(one) to create a new UInt16 initialized with the value of one, and uses this value in place of the original:

let twoThousand: UInt16 = 2_000
let one: UInt8 = 1
let twoThousandAndOne = twoThousand + UInt16(one)
//Because both sides of the addition are now of type UInt16, the addition is allowed. The output constant (twoThousandAndOne) is inferred to be of type UInt16, because it’s the sum of two UInt16 values.

//整数和浮点数的转换必须显式指定类型：
let three = 3
let pointOneFourOneFiveNine = 0.14159
let pai = Double(three) + pointOneFourOneFiveNine
// pai equals 3.14159, and is inferred to be of type Double


//浮点数到整数的反向转换同样行，整数类型可以用 Double 或者 Float 类型来初始化：
let integerPi = Int(pi)
// integerPi equals 3, and is inferred to be of type Int
//注意： 结合数字类常量和变量不同于结合数字类字面量。字面量3可以直接和字面量0.14159相加，因为数字字面量本身没有明确的类型。它们的类型只在编译器需要求值的时候被推测。



//类型别名
//当你想要给现有类型起一个更有意义的名字时，类型别名非常有用。假设你正在处理特定长度的外部资源的数据：
typealias AudioSample = UInt16
//定义了一个类型别名之后，你可以在任何使用原始名的地方使用别名：

var maxAmplitudeFound = AudioSample.min
// maxAmplitudeFound 现在是 0。本例中，AudioSample被定义为UInt16的一个别名。因为它是别名，AudioSample.min实际上是UInt16.min，所以会给maxAmplitudeFound赋一个初值0。


//Swift has a basic Boolean type, called Bool. Boolean values are referred to as logical, because they can only ever be true or false. Swift provides two Boolean constant values, true and false:

let orangesAreOrange = true
let turnipsAreDelicious = false

//Boolean values are particularly useful when you work with conditional statements such as the if statement:

if turnipsAreDelicious {
    print("Mmm, tasty turnips!")
} else {
    print("Eww, turnips are horrible.")
}
// Prints "Eww, turnips are horrible."




//元组：
//Tuples group multiple values into a single compound value. The values within a tuple can be of any type and don’t have to be of the same type as each other.
//In this example, (404, "Not Found") is a tuple that describes an HTTP status code. An HTTP status code is a special value returned by a web server whenever you request a web page. A status code of 404 Not Found is returned if you request a webpage that doesn’t exist.
//元组（tuples）把多个值组合成一个复合值。元组内的值可以是任意类型，并不要求是相同类型。
//你可以把任意顺序的类型组合成一个元组，这个元组可以包含所有类型。只要你想，你可以创建一个类型为 (Int, Int, Int) 或者 (String, Bool) 或者其他任何你想要的组合的元组。
//下面这个例子中，(404, "Not Found") 是一个描述 HTTP 状态码（HTTP status code）的元组。HTTP 状态码是当你请求网页的时候 web 服务器返回的一个特殊值。如果你请求的网页不存在就会返回一个 404 Not Found 状态码。
let http404Error = (404, "Not Found")
// http404Error is of type (Int, String), and equals (404, "Not Found")




//You can create tuples from any permutation of types, and they can contain as many different types as you like. There’s nothing stopping you from having a tuple of type (Int, Int, Int), or (String, Bool), or indeed any other permutation you require.
//You can decompose a tuple’s contents into separate constants or variables, which you then access as usual:
//你可以将一个元组的内容分解（decompose）成单独的常量和变量，然后你就可以正常使用它们了：
let (statusCode, statusMessage) = http404Error
print("The status code is \(statusCode)")
// Prints "The status code is 404"
print("The status message is \(statusMessage)")
// Prints "The status message is Not Found"




//当你分解元组的时候，如果只需要使用其中的一部分数据，不需要的数据可以用下滑线（ _ ）代替：
let (justTheStatusCode, _) = http404Error
print("The status code is \(justTheStatusCode)")
// Prints "The status code is 404"


//另外一种方法就是利用从零开始的索引数字访问元组中的单独元素：
print("The status code is \(http404Error.0)")
// Prints "The status code is 404"
print("The status message is \(http404Error.1)")
// Prints "The status message is Not Found"


//你可以在定义元组的时候给其中的单个元素命名：
let http200Status = (statusCode: 200, description: "OK")
//在命名之后，你就可以通过访问名字来获取元素的值了：
print("The status code is \(http200Status.statusCode)")
// Prints "The status code is 200"

//另外一种方法就是利用从零开始的索引数字访问元组中的单独元素：
print("The status code is \(http200Status.0)")

print("The status message is \(http200Status.description)")
// Prints "The status message is OK"
//注意： 元组在临时组织值的时候很有用，但是并不适合创建复杂的数据结构。如果你的数据结构并不是临时使用，请使用类或者结构体而不是元组。请参考类和结构体。




//**************************************************************************************************************************
//可选类型
//下面的栗子演示了可选项如何作用于值的缺失，Swift 的 Int 类型中有一个初始化器，可以将 String 值转换为一个 Int 值。然而并不是所有的字符串都可以转换成整数。字符串 “123” 可以被转换为数字值 123  ，但是字符串  "hello, world" 就显然不能转换为一个数字值。
//在下面的栗子中，试图利用初始化器将一个 String 转换为 Int ：
let possibleNumber = "123"
let convertedNumber = Int(possibleNumber)
// convertedNumber is inferred to be of type "Int?", or "optional Int"
//因为这个初始化器可能会失败，所以他会返回一个可选的 Int ，而不是 Int 。可选的 Int 写做 Int? ，而不是 Int 。问号明确了它储存的值是一个可选项，意思就是说它可能包含某些 Int  值，或者可能根本不包含值。（他不能包含其他的值，例如 Bool 值或者 String 值。它要么是 Int 要么什么都没有。）



//你可以通过给可选变量赋值一个 nil 来将之设置为没有值：
var serverResponseCode: Int? = 404
// serverResponseCode contains an actual Int value of 404
serverResponseCode = nil
// serverResponseCode now contains no value
//注意：nil 不能用于非可选的常量或者变量，如果你的代码中变量或常量需要作用于特定条件下的值缺失，可以给他声明为相应类型的可选项。



//如果你定义的可选变量没有提供一个默认值，变量会被自动设置成 nil 。
var surveyAnswer: String?
// surveyAnswer is automatically set to nil
//注意：Swift 中的 nil 和Objective-C 中的 nil 不同，在 Objective-C 中 nil 是一个指向不存在对象的指针。在 Swift中， nil不是指针，他是值缺失的一种特殊类型，任何类型的可选项都可以设置成 nil 而不仅仅是对象类型。


//If Statements and Forced Unwrapping
//if 语句以及强制解析
//你可以利用 if 语句通过比较 nil 来判断一个可选中是否包含值。利用相等运算符 （ == ）和不等运算符（ != ）。
//如果一个可选有值，他就“不等于” nil ：
if convertedNumber != nil {
    print("convertedNumber contains some integer value.")
}
// Prints "convertedNumber contains some integer value."



//forced unwrapping
//强制解析
//Once you’re sure that the optional does contain a value, you can access its underlying value by adding an exclamation mark (!) to the end of the optional’s name. The exclamation mark effectively says, “I know that this optional definitely has a value; please use it.” This is known as forced unwrapping of the optional’s value:
//当你确定可选类型确实包含值之后，你可以在可选的名字后面加一个感叹号（!）来获取值。这个惊叹号表示“我知道这个可选有值，请使用它。”这被称为可选值的强制解析（forced unwrapping）：
if convertedNumber != nil {
    print("convertedNumber has an integer value of \(convertedNumber!).") //强制解析（forced unwrapping）
}
// Prints "convertedNumber has an integer value of 123."
//注意:使用 ! 来获取一个不存在的可选值会导致运行错误，在使用!强制展开之前必须确保可选项中包含一个非 nil 的值。
//**************************************************************************************************************************






//**************************************************************************************************************************
//Optional Binding
//可选绑定

//You use optional binding to find out whether an optional contains a value, and if so, to make that value available as a temporary constant or variable. Optional binding can be used with if and while statements to check for a value inside an optional, and to extract that value into a constant or variable, as part of a single action.
//使用可选绑定（optional binding）来判断可选类型是否包含值，如果包含就把值赋给一个（临时常量或者变量）。可选绑定可以用在 if 和 while 语句中，这条语句不仅可以用来判断可选类型中是否有值，同时可以将可选类型中的值赋给一个常量或者变量。
//像下面这样在 if 语句中写一个可选绑定：
if let actualNumber = Int(possibleNumber) {
    print("\'\(possibleNumber)\' has an integer value of \(actualNumber)")
} else {
    print("\'\(possibleNumber)\' could not be converted to an integer")
}
// 输出 "'123' has an integer value of 123"
//这段代码可以被理解为：“如果 Int(possibleNumber) 返回的可选 Int 包含一个值，创建一个叫做 actualNumber 的新常量并将可选包含的值赋给它。” 如果转换成功，actualNumber 常量可以在 if 语句的第一个分支中使用。它已经被可选类型包含的值初始化过，所以不需要再使用 ! 后缀来获取它的值。在这个例子中，actualNumber 只被用来输出转换结果。你可以在可选绑定中使用常量和变量。如果你想在if语句的第一个分支中操作 actualNumber 的值，你可以改成 if var actualNumber，这样可选类型包含的值就会被赋给一个变量而非常量。



//You can include as many optional bindings and Boolean conditions in a single if statement as you need to, separated by commas. If any of the values in the optional bindings are nil or any Boolean condition evaluates to false, the whole if statement’s condition is considered to be false. The following if statements are equivalent:
//你可以在可选绑定中使用常量和变量。如果你想在if语句的第一个分支中操作 actualNumber 的值，你可以改成 if var actualNumber，这样可选类型包含的值就会被赋给一个变量而非常量。你可以包含多个可选绑定或多个布尔条件在一个 if 语句中，只要使用“逗号”分开就行。只要有任意一个可选绑定的值为nil，或者任意一个布尔条件为false，则整个if条件判断为false，这时你就需要使用嵌套 if 条件语句来处理，如下所示：
//下面的两个 if 语句是等价的：
if let firstNumber = Int("4"), let secondNumber = Int("42"), firstNumber < secondNumber && secondNumber < 100 {//可以包含多个可选绑定或多个布尔条件在一个 if 语句中
    print("\(firstNumber) < \(secondNumber) < 100")
}
// Prints "4 < 42 < 100"

if let firstNumber = Int("4") {
    if let secondNumber = Int("42") {
        if firstNumber < secondNumber && secondNumber < 100 {
            print("\(firstNumber) < \(secondNumber) < 100")
        }
    }
}
// Prints "4 < 42 < 100"
//这里要注意在可选绑定里的临时常量与临时变量的概念
//注意:如同提前退出中描述的那样，使用 if 语句创建的常量和变量只在if语句的函数体内有效。相反，在 guard 语句中创建的常量和变量在 guard 语句后的代码中也可用。
//**************************************************************************************************************************



 
//**************************************************************************************************************************

//Implicitly Unwrapped Optionals
//隐式解析可选类型
//可选类型暗示了常量或者变量可以“没有值”。可以通过if语句来判断是否有值，如果有值的话可以通过可选绑定来解析值。有时候在程序架构中，第一次被赋值之后，可以确定一个可选类型总会有值。在这种情况下，每次都要判断和解析可选值是非常低效的，因为可以确定它总会有值。这种类型的可选状态被定义为隐式解析可选类型（implicitly unwrapped optionals）。把想要用作可选的类型的后面的问号（String?）改成感叹号（String!）来声明一个隐式解析可选类型。当可选类型被第一次赋值之后就可以确定之后一直有值的时候，隐式解析可选类型非常有用。隐式解析可选类型主要被用在Swift中类的构造过程中，请参考无主引用以及隐式解析可选属性。一个隐式解析可选类型其实就是一个普通的可选类型，但是可以被当做非可选类型来使用，并不需要每次都使用解析来获取可选值。

let assumedString: String! = "An implicitly unwrapped optional string."//隐式解析可选类型(Implicitly Unwrapped Optionals)。
//把想要用作可选的类型的后面的问号（String?）改成感叹号（String!）来声明一个隐式解析可选类型。
let implicitString: String = assumedString // no need for an exclamation mark
//你可以把隐式解析可选类型当做一个可以自动解析的可选类型。你要做的只是声明的时候把感叹号放到类型的结尾，而不是每次取值的可选名字的结尾。
//注意： 如果你在隐式解析可选类型没有值的时候尝试取值，会触发运行时错误。和你在没有值的普通可选类型后面加一个惊叹号一样。

//下面的例子展示了可选类型 String 和隐式解析可选类型 String 之间的区别：
let possibleString: String? = "An optional string."
let forcedString: String = possibleString! // requires an exclamation mark



//You can still treat an implicitly unwrapped optional like a normal optional, to check if it contains a value:
//你仍然可以把隐式解析可选类型当做普通可选类型来判断它是否包含值：
if assumedString != nil {
    print(assumedString!)
}
// Prints "An implicitly unwrapped optional string."

//You can also use an implicitly unwrapped optional with optional binding, to check and unwrap its value in a single statement:
//你也可以在可选绑定中使用隐式解析可选类型来检查并解析它的值：
if let definiteString = assumedString {
    print(definiteString)
}
// Prints "An implicitly unwrapped optional string."
//Don’t use an implicitly unwrapped optional when there’s a possibility of a variable becoming nil at a later point. Always use a normal optional type if you need to check for a nil value during the lifetime of a variable.
//如果一个变量之后可能变成 nil 的话请不要使用隐式解析可选类型。如果你需要在变量的生命周期中判断是否是 nil 的话，请使用普通可选类型。
//**************************************************************************************************************************








